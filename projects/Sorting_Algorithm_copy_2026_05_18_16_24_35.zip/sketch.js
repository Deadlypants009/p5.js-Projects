let board = [];

let checker0;
let checker1;

let width;
let height;

let num = 50;
let end = num;

function setup() {
  
  width = windowWidth;
  height = windowHeight;
  
  createCanvas(width, height);
  
  for (let i = 0; i < num; i++) {
    board[i] = new Columns(height / num * i + height / num, i, i);
  } 

  
  mix(board);
    
  checker0 = new Checker(0);
  checker1 = new Checker(checker0.x + 1);
  
  // saveGif('bubble', 7.9);
}

function draw() {
  background(0);
    
  for (let i = 0; i < board.length; i++) {
    board[i].show();
  }
  
  checker0.x += 1;
  checker1.x = checker0.x + 1;

  if (end == 1 && checker1.x >= num) {
    noLoop();
    // console.log(millis());
  } else {
  
  if (checker0.check() > checker1.check() && checker0.check() != checker1.check()) {
    
    temp1 = board.find(board => board.x == checker0.x);
    temp2 = board.find(board => board.x == checker1.x);
    
    swap(temp1, temp2);
  }
  }
  
  
  if (checker1.x == end - 1) {
    
    checker0.x = -1;
    end -= 1;
  }
  
}

function swap(col1, col2) {
    
  let temp = col1.x;
  
  col1.x = col2.x;
  col2.x = temp;
  
}

function mix(arr) {
  
  for (let i = 0; i < arr.length * 4; i++) {
    
    let temp = random(arr);
    let temp2 = random(arr);
    
    swap(temp, temp2);
    
  }
}



class Checker {
  
  constructor(x) {
    
    this.x = x;
    
  }
  
  check() {
    
    let temp1 = board.find(board => board.x == this.x)
    
    return temp1.value;
    
  }
}

class Columns{
  
  constructor(value, x, index) {
    
    this.x = x;
    this.value = value;
    this.h = this.value;
    this.w = width / num;
    this.index = index;
    
  }
  
  show() {
    
    noStroke();
    fill(255);
    if (checker1.x == this.x || checker0.x == this.x) {
      fill(255, 0, 0);
    }
    if (end == 1 && checker1.x >= this.x) {
      fill(0, 255, 0);
    }
    rect(this.x * this.w, height - this.value, this.w, this.h);
  }
}