class Dragger {
  
  constructor(x, y, d) {
    this.x = x;
    this.y = y;
    this.direction = d;
    this.radius = 8;
    this.mouseOver = false;
    this.pressed = false;
  }
  
  show() {
    
    if (this.mouseOver) {
      fill(200, 0, 0);
    } else {
      fill(255, 0, 0);
    }
    noStroke();
    circle(this.x, this.y, this.radius * 2);
    
  }
  
  update() {
    
    if (dist(mouseX, mouseY, this.x, this.y) < this.radius) {
      this.mouseOver = true;
    } else {
      this.mouseOver = false;
    }
    
    if (mouseIsPressed && this.mouseOver) {
      this.pressed = true;
    }
    
    if (this.pressed) {
      if (this.direction == 'vertical') {
        this.y = mouseY;
      }
      if (this.direction == 'horizontal') {
        this.x = mouseX;
      }
      if (this.direction == 'all') {
        this.x = mouseX;
        this.y = mouseY;
      }
    }
    
  }
  
}