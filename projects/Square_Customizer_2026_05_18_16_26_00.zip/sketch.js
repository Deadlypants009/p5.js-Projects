let objects = [];

function setup() {
  createCanvas(400, 400);
  
  objects.push(new Obj(width / 2, height / 2, 100, 100));
}

function draw() {
  background(0);
  
  for (let i = 0; i < objects.length; i++) {
    objects[i].update();
    objects[i].show();
  }
}



function mouseReleased() {
  for (let i = 0; i < objects.length; i++) {
    for (let j = 0; j < objects[i].draggers.length; j++) {
      objects[i].draggers[j].pressed = false;
    }
  }
}