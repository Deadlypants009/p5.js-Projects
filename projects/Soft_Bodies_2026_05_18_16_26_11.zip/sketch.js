let particles = [];
let springs = [];

let gravity = 1;
let elasticity = 0;

let stiffness = 0.8;
let damping = 0.2;

let running = true;

let mouseForce = 3;
let mouseDown = false;

function setup() {
  createCanvas(400, 400);
  
  makeSquare();
  // makeCircle();

}

function draw() {
  background(0);
  
  if (running) {
    
    for (let spring of springs) {
      spring.update();
    }
    
    for (let particle of particles) {
      particle.applyForce(createVector(0, gravity));
      particle.edges();
      particle.update();
    }
  }
  
  
  for (let spring of springs) {
    spring.show();
  }
  for (let particle of particles) {
    particle.show();
  }
  
  if (mouseDown) {
    let mouseVector = createVector(mouseX, mouseY);
    for (let particle of particles) {
      let force = p5.Vector.sub(particle.position, mouseVector);
      force.setMag(mouseForce);
      force.mult(-1);
      particle.applyForce(force);
    }
  }
  
}


function makeCircle() {
  
  let radius = 100;
  
  particles.push(new Particle(200, 200, 5, 10));
  
  for (let i = 0; i < TWO_PI; i += PI/6) {
    let posX = cos(i) * radius;
    let posY = sin(i) * radius;
    particles.push(new Particle(posX + 200, posY + 200, 5, 10));
  }
  
  let distance = p5.Vector.dist(particles[1].position, particles[2].position);
  
  for (let i = 1; i < 12; i++) {
    springs.push(new Spring(particles[0], particles[i], radius, stiffness, damping));
    springs.push(new Spring(particles[i], particles[i + 1], distance, stiffness, damping));
  }
  
  springs.push(new Spring(particles[12], particles[0], radius, stiffness, damping));
  springs.push(new Spring(particles[1], particles[12], distance, stiffness, damping));
  
}


function makeSquare() {
  for (let i = 0; i < 4; i++) {
    for (let j = 0; j < 4; j++) {
      particles.push(new Particle(i * 50 + 100, j * 50 + 100, 5, 10));
    }
  }
  
  for (let i = 0; i < 4; i++) {
    for (let j = 0; j < 4; j++) {
      if (j < 3) {
        springs.push(new Spring(particles[i * 4 + j], particles[i * 4 + j + 1], 50, stiffness, damping));
      }
      if (i < 3) {
        springs.push(new Spring(particles[i * 4 + j], particles[(i + 1) * 4 + j], 50, stiffness, damping));
      }
      if (i < 3 && j < 3) {
        springs.push(new Spring(particles[i * 4 + j], particles[(i + 1) * 4 + j + 1], 50 * sqrt(2), stiffness, damping))
      }
      if (i < 3 && j > 0) {
        springs.push(new Spring(particles[i * 4 + j], particles[(i + 1) * 4 + j - 1], 50 * sqrt(2), stiffness, damping))
      }
    }
  }
}


function mousePressed() {
  mouseDown = true;
}

function mouseReleased() {
  mouseDown = false;
}


function keyPressed() {
  if (keyCode == 32) {
    running = !running;
  }
}