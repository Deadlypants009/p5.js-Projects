class Particle {
  constructor(x, y, z) {
    
    this.radius = 5;
    
    this.position = createVector(x, y, z);
    this.projectedScale = 1;
    this.projectedPosition = createVector(0, 0);
    
  }

  
  project() {
    
    this.projectedPosition = createVector(0, 0);
    
    this.projectedScale = PERSPECTIVE / (PERSPECTIVE + this.position.z);
    let x = this.position.x * this.projectedScale + projectionCenter.x;
    let y = this.position.y * this.projectedScale + projectionCenter.y;
    this.projectedPosition = createVector(x, y);
    
  }
  
  show() {
    fill(0);
    noStroke();
    this.project();
    circle(this.projectedPosition.x, this.projectedPosition.y, this.radius * 2);
  }
  
  
}