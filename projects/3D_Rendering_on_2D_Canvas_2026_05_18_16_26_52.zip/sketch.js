const PERSPECTIVE = 800;
let projectionCenter;

let particles = [];

function setup() {
  createCanvas(400, 400);
  
  projectionCenter = createVector(width / 2, height / 2);

  for (let i = 0; i < 100; i++) {
    
    let pos = p5.Vector.random3D().setMag(50);
    particles.push(new Particle(pos.x, pos.y, pos.z));
    
  }
}

function draw() {
  background(255);
  
  for (let particle of particles) {
    particle.show();
    particle.position.x--;
  }
}