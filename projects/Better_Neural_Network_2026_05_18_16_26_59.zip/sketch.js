let nn;

let sizes = [5, 15, 7, 2];

let inputs = [1, 1, 1, 1, 1];
let outputs = [0.4, -0.2];

function setup() {
  createCanvas(400, 400);
  
  nn = new NeuralNetwork(sizes);
  
  nn.calculateCosts(inputs, outputs);
}

function draw() {
  background(255);
  
  visualizeNeuralNetwork(width / 2 - 100, height / 2 - 100, 200, 200, sizes);
}

