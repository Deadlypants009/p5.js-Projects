class NeuralNetwork {
  
  constructor(params) {
    
    this.sizes = params;
    
    this.layers = [];
        
    for (let i = 0; i < this.sizes.length - 1; i++) {
      this.layers.push(new Layer(this.sizes[i], this.sizes[i + 1]));
    }
    
  }
  
  feedForward(inputs) {
    
    let x = inputs;
    
    for (let i = 0; i < this.layers.length; i++) {
            
      x = this.layers[i].calculateOutputs(x);
      for (let i = 0; i < x.length; i++) {
        x[i] = activationFunction(x[i]);
      }
      
    }
    
    return x;
    
  }
  
  totalCost(inputs, outputs) {
    
    let nnOutputs = this.feedForward(inputs);
    
    let cost = 0;
    
    for (let i = 0; i < outputs.length; i++) {
      cost += abs(outputs[i] - nnOutputs[i]);
    }
    
    return cost;
  }
  
  calculateCosts(inputs, outputs) {
    
    // ---------------
    // gets the costs of the output layer
    
    let nnOutputs = this.feedForward(inputs);
    
    let costs = new Array(outputs.length);
    for (let i = 0; i < costs.length; i++) {
      costs[i] = 0;
    }
    
    for (let i = 0; i < outputs.length; i++) {
      costs[i] += outputs[i] - nnOutputs[i];
    }
    
    // -------------------------
    
    // gets the cost for second to last layer
    // because the output layer isn't a layer object
    
    let sllCost = new Array(this.sizes[this.sizes.length - 2]);
    
    for (let i = 0; i < this.sizes[this.sizes.length - 2]; i++) {
      
      let c = 0;
      
      for (let j = 0; j < this.sizes[this.sizes.length - 1]; j++) {
        
        c += costs[j] * this.layers[this.layers.length - 1].weights.data[j][i];
        
      }
      
      sllCost[i] = c;
      
    }
    
    this.layers[this.layers.length - 1].costs = sllCost;
    
    // -------------------------------
    // calculate the rest of the layers costs
    
    
    // for every layer
    for (let i = this.layers.length - 2; i >= 0; i--) {
      
      let layerCost = new Array(this.sizes[i]);
      
      // for every neuron in this layer
      for (let j = 0; j < this.sizes[i]; j++) {
        
        let neuronCost = 0;
        
        // for every neuron in the previous layer
        for (let k = 0; k < this.sizes[i + 1]; k++) {
          
          neuronCost += this.layers[i + 1].costs[k] * this.layers[i].weights.data[k][j];
                    
        }
        
        layerCost[j] = neuronCost;
        
      }
      
      this.layers[i].costs = layerCost;
      
    }
    
  }
  
}


class Layer {
  
  constructor(inputSize, outputSize) {
    
    this.inputSize = inputSize;
    this.outputSize = outputSize;
    
    this.costs = new Array(this.inputSize);
    
    this.weights = new Matrix(this.outputSize, this.inputSize);
    randomizeMatrix(this.weights);
    this.biases = new Array(this.outputSize);
    randomizeArray(this.biases);
    
  }
  
  calculateOutputs(inputs) {
    
    let outputs = new Array(this.outputSize);
    for (let i = 0; i < outputs.length; i++) {
      outputs[i] = 0;
    }
    
    for (let i = 0; i < this.outputSize; i++) {
      
      for (let j = 0; j < inputs.length; j++) {
        
        outputs[i] += inputs[j] * this.weights.data[i][j];
        
      }
      outputs[i] += this.biases[i]; 
    }
    return outputs;
  }
  
}

function activationFunction(x) {
  // sigmoid function
  return 2 / (1 + Math.exp(-x)) - 1;
}

function randomizeArray(arr) {
  for (let i = 0; i < arr.length; i++) {
    arr[i] = random(-1, 1);
  }
}