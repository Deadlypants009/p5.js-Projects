class Matrix {
  constructor(rows, cols) {
    this.rows = rows;
    this.cols = cols;
    this.data = new Array(this.rows);
    
    for (let i = 0; i < this.rows; i++) {
      this.data[i] = new Array(this.cols);
      for (let j = 0; j < this.cols; j++) {
        this.data[i][j] = 0;
      }
    } 
  }
  
  static add(a, b) {
    let output = new Matrix(a.rows, a.cols);
    if (b instanceof Matrix) {
      for (let i = 0; i < a.rows; i++) {
        for (let j = 0; j < a.cols; j++) {
          output.data[i][j] = a.data[i][j] + b.data[i][j];
        }
      }
    } else {
      for (let i = 0; i < a.rows; i++) {
        for (let j = 0; j < a.cols; j++) {
          output.data[i][j] = a.data[i][j] + b;
        }
      }
    }
    return output;
  }
  
  static map(a, fn) {
    let output = new Matrix(a.rows, a.cols);
    for (let i = 0; i < a.rows; i++) {
      for (let j = 0; j < a.cols; j++) {
        output.data[i][j] = fn(a.data[i][j]);
      }
    }
    return output;
  }
  
  
  static scalar(a, n) {
    let output = new Matrix(a.rows, a.cols);
    for (let i = 0; i < a.rows; i++) {
      for (let j = 0; j < a.cols; j++) {
        output.data[i][j] = a.data[i][j] * n;
      }
    }
    return output;
  }
  
  
  static transpose(a) {
    let output = new Matrix(a.cols, a.rows);
    for (let i = 0; i < a.rows; i++) {
      for (let j = 0; j < a.cols; j++) {
        output.data[j][i] = a.data[i][j];
      }
    }
    return output;
  }
  
  
  static matrixProduct(a, b) {
    let output = new Matrix(a.rows, b.cols);
    if (a.cols != b.rows) {
      console.log("a.cols must equal b.rows");
      return undefined;
    }
    for (let i = 0; i < output.rows; i++) {
      for (let j = 0; j < output.cols; j++) {
        let sum = 0;
        for (let k = 0; k < a.cols; k++) {
          sum += a.data[i][k] * b.data[k][j];
        }
        output.data[i][j] = sum;
      }
    }
    return output;
  }
}


function randomizeMatrix(matrix) {
  for (let i = 0; i < matrix.rows; i++) {
    for (let j = 0; j < matrix.cols; j++) {
      matrix.data[i][j] = random(-1, 1);
    }
  }
}


function fromArray(arr) {
  let output = new Matrix(arr.length, 1);
  for (let i = 0; i < arr.length; i++) {
    output.data[i][0] = arr[i];
  }
  return output;
}


function toArray(matrix) {
  let output = [];
  for (let i = 0; i < matrix.rows; i++) {
    for (let j = 0; j < matrix.cols; j++) {
      output.push(matrix.data[i][j]);
    }
  }
  return output;
}