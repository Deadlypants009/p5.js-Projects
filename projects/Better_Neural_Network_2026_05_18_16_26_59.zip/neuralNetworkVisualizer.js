function visualizeNeuralNetwork(x, y, w, h, params) {
  
  fill(0);
  stroke(0);
  strokeWeight(1);
  
  let circleDiameter = 8;
  
  let s = w / (params.length - 1);
  
  for (let i = 0; i < params.length; i++) {
    
    for (let j = 0; j < params[i]; j++) {
      
      let yoffset = h / params[i];
      
      let c1posX = i * s + x;
      let c1posY = j * yoffset + yoffset / 2 + y;
      circle(c1posX, c1posY, circleDiameter);
      
      for (let k = 0; k < params[i + 1]; k++) {
        
        let yoffset2 = h / params[i + 1];
        
        let c2posX = (i + 1) * s + x;
        let c2posY = k * yoffset2 + yoffset2 / 2 + y;
        
        line(c1posX, c1posY, c2posX, c2posY);
        
      }
      
    }
    
  }
  
}