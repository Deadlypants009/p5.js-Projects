let orbit;
let smallCircle;
const SPEED = 0.05;
let pos = [];

let saveButton;

function setup() {
  createCanvas(400, 400);
  
  colorMode(HSB);
  
  saveButton = createButton('save');
  
  orbit = {
    posX: 100,
    posY: width / 2,
    radius: 50
  }
  
  smallCircle = {
    angle: 0,
    distance: orbit.radius
  }
}

function draw() {
  background(0);
  
  stroke(255);
  noFill();
  circle(orbit.posX, orbit.posY, orbit.radius * 2);
  
  push();
  translate(orbit.posX, orbit.posY);
  let x = sin(smallCircle.angle) * smallCircle.distance;
  let y = cos(smallCircle.angle) * smallCircle.distance;
  fill(255);
  circle(x, y, 10);
  pop();
  
  pos.push(y);
  
  push();
  translate(orbit.posX, orbit.posY);
  for (let i = 0; i < pos.length; i++) {
    if (frameCount - i < width) {
      strokeWeight(4);
      stroke(i * 0.465 % 360, 100, 100);
      point(frameCount - i + orbit.posX, pos[i]);
    }
  }
  pop();
  
  push();
  translate(orbit.posX, orbit.posY);
  line(x, y, orbit.posX, pos[pos.length - 1]);
  pop();
  
  smallCircle.angle += SPEED;
  
  saveButton.mousePressed(() => {
    saveGif('sineWave', 12.6);
  });
}

function keyPressed() {
  //press space to save
  if (keyCode === 32) {
    saveGif('sineWave', 12.6);
  }
}