let anchor1;
let anchor2;
let control1;
let control2;


function setup() {
  createCanvas(400, 400);
  
  anchor1 = new Dragger(0, height / 2);
  anchor2 = new Dragger(width, height / 2);
  control1 = new Dragger(100, 100);
  control2 = new Dragger(300, 300);
}

function draw() {
  background(0);
  
  
  stroke(255);
  noFill();
  bezier(anchor1.pos.x, anchor1.pos.y, control1.pos.x, control1.pos.x, control2.pos.x, control2.pos.y, anchor2.pos.x, anchor2.pos.y);
  
  anchor1.show();
  anchor1.update();
  anchor2.show();
  anchor2.update();
  control1.show();
  control1.update();
  control2.show();
  control2.update();
}



class Dragger {
  
  constructor(x, y) {
    this.pos = createVector(x, y);
    this.radius = 8;
    this.mouseOver = false;
    this.pressed = false;
  }
  
  show() {
    
    if (this.mouseOver) {
      fill(150, 0, 0);
    } else {
      fill(255, 0, 0);
    }
    circle(this.pos.x, this.pos.y, this.radius * 2);
    
  }
  
  update() {
    
    if (dist(mouseX, mouseY, this.pos.x, this.pos.y) < this.radius) {
      this.mouseOver = true;
    } else {
      this.mouseOver = false;
    }
    
    if (mouseIsPressed && this.mouseOver) {
      this.pressed = true;
    }
    
    if (this.pressed) {
      let mousePos = createVector(mouseX, mouseY);
      this.pos.set(mousePos);
    }
    
  }
  
}


function mouseReleased() {
  
  anchor1.pressed = false;
  anchor2.pressed = false;
  control1.pressed = false;
  control2.pressed = false;
  
}