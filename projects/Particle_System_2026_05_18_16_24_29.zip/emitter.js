class Emitter {
  
  constructor(x, y) {
    
    this.pos = createVector(x, y);
    this.particles = [];
    
  }
  
  update() {
    
    for (let i = 0; i < this.particles.length; i++) {
      
      this.particles[i].update();
      this.particles[i].show();
      
    }
    
    this.addParticle();
    this.checkDead();
    
    
  }
  
  addParticle() {
    
    this.particles.push(new Particle(this.pos.x, this.pos.y, 0, 0, random(-1, 1), random(-1, 1)));
    
  }
  
  checkDead() {
    
    for (let i = 0; i < this.particles.length; i++) {
      
      if (this.particles[i].lifeSpan <= 0) {
        
        this.particles.splice(i, 1);
        
      }
    }
  }
  
}