let gravity;
let emitters  = [];

function setup() {
  createCanvas(400, 400);
  
  gravity = createVector(0, 0.1);
}

function draw() {
  background(0);
  
  for (let emitter of emitters) {
    emitter.update();
  }
  
}

function mousePressed() {
  emitters.push(new Emitter(mouseX, mouseY));
}