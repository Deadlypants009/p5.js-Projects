class Particle {
  
  constructor(x, y, xv, yv, xa, ya) {
    
    this.pos = createVector(x, y);
    this.vel = createVector(xv, yv);
    this.acc = createVector(xa, ya);
    this.lifeSpan = 255;
    this.r = 4;
    
  }
  
  update() {
    
    this.lifeSpan -= 3;
    
    this.applyForce(gravity);
    
    this.vel.add(this.acc);
    this.pos.add(this.vel);
    
    this.acc.set(0);
  }
  
  applyForce(force) {
    
    this.acc.add(force);
    
  }
  
  show() {
    
    noStroke();
    fill(255, this.lifeSpan);
    circle(this.pos.x, this.pos.y, this.r * 2);
    
  }
}