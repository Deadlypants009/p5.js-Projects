let grid;

let cols, rows;
let w = 20; // cell size

// grid contents { north, east, south, west }
// moves are booleans
// if north == true then there is a line on the north side of the cell

let currentPosition;

let finished = false;

function setup() {
  createCanvas(windowWidth - windowWidth % w, windowHeight - windowHeight % w);
  
  cols = floor(width / w);
  rows = floor(height / w);
  
  grid = create2DArray(cols, rows);
  
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      grid[i][j] = { north: true, east: true, south: true, west: true };
    }
  }
  
  currentPosition = createVector(0, 0);
}

function draw() {
  background(200);
  
  if (!finished) {

    displayGrid();
    
    noStroke();
    fill(0, 0, 255);
    rect(currentPosition.x * w, currentPosition.y * w, w, w);

    let moves = getValidMoves(currentPosition);

    if (moves.length > 0) {

      randomWalk(moves);

    } else {

      huntAndKill();

    }
  } else {
    background(200);
    displayGrid();
    console.log("finished");
    noLoop();
  }
  
}

function huntAndKill() {
  // console.log("stuck");
  
  let unVisitedCells = 0;
  
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      
      if (!isUnvisited(grid[i][j])) {
        continue;
      }
      
      unVisitedCells++;
      
      let moves = [];
      
      if (i < cols - 1) {
        if (!isUnvisited(grid[i + 1][j])) {
          moves.push(createVector(1, 0));
        }
      }
      if (i > 0) {
        if (!isUnvisited(grid[i - 1][j])) {
          moves.push(createVector(-1, 0));
        }
      }
      if (j < rows - 1) {
        if (!isUnvisited(grid[i][j + 1])) {
          moves.push(createVector(0, 1));
        }
      }
      if (j > 0) {
        if (!isUnvisited(grid[i][j - 1])) {
          moves.push(createVector(0, -1));
        }
      }
      
      if (moves.length > 0) {
        
        let move = random(moves);
        
        if (move.x == 1) {
          grid[i][j].east = false;
          grid[i + 1][j].west = false;
          currentPosition = createVector(i + 1, j);
          return;
        }
        if (move.x == -1) {
          grid[i][j].west = false;
          grid[i - 1][j].east = false;
          currentPosition = createVector(i - 1, j);
          return;
        }
        if (move.y == 1) {
          grid[i][j].south = false;
          grid[i][j + 1].north = false;
          currentPosition = createVector(i, j + 1);
          return;
        }
        if (move.y == -1) {
          grid[i][j].north = false;
          grid[i][j - 1].south = false;
          currentPosition = createVector(i, j - 1);
          return;
        }
        
      }
      
      
    }
  }
  
  if (unVisitedCells == 0) {
    finished = true;
  }
  
}

function randomWalk(moves) {
  
  let m = random(moves);
  
  if (m.x == -1) {
      grid[currentPosition.x][currentPosition.y].west = false;
      grid[currentPosition.x - 1][currentPosition.y].east = false;
      currentPosition.add(m);
    }
    if (m.x == 1) {
      grid[currentPosition.x][currentPosition.y].east = false;
      grid[currentPosition.x + 1][currentPosition.y].west = false;
      currentPosition.add(m);
    }
    if (m.y == -1) {
      grid[currentPosition.x][currentPosition.y].north = false;
      grid[currentPosition.x][currentPosition.y - 1].south = false;
      currentPosition.add(m);
    }
    if (m.y == 1) {
      grid[currentPosition.x][currentPosition.y].south = false;
      grid[currentPosition.x][currentPosition.y + 1].north = false;
      currentPosition.add(m);
    }
}

function displayGrid() {
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      
      let cell = grid[i][j];
      
      if (isUnvisited(cell)) {
        noStroke();
        fill(100);
        rect(i * w, j * w, w, w);
      }
      
      stroke(0);
      strokeWeight(1);
      
      if (cell.north) {
        line(i * w, j * w, i * w + w, j * w);
      }
      if (cell.east) {
        line(i * w + w, j * w, i * w + w, j * w + w);
      }
      if (cell.south) {
        line(i * w, j * w + w, i * w + w, j * w + w);      
      }
      if (cell.west) {
        line(i * w, j * w, i * w, j * w + w);        
      }
      
    }
  }
}

function getValidMoves(position) {
  let validMoves = [];
  if (position.x != 0) {
    if (isUnvisited(grid[position.x - 1][position.y])) {
      validMoves.push(createVector(-1, 0));
    }
  }
  if (position.x < cols - 1) {
    if (isUnvisited(grid[position.x + 1][position.y])) {
      validMoves.push(createVector(1, 0));
    }
  }
  if (position.y != 0) {
    if (isUnvisited(grid[position.x][position.y - 1])) {
      validMoves.push(createVector(0, -1));
    }
  }
  if (position.y < rows - 1) {
    if (isUnvisited(grid[position.x][position.y + 1])) {
      validMoves.push(createVector(0, 1));
    }
  }
  return validMoves;
}

function isUnvisited(cell) {
  let numSides = 0;
  
  if (cell == null) {
    return;
  }
  
  if (cell.north) {
    numSides++;
  }
  if (cell.east) {
    numSides++;
  }
  if (cell.south) {
    numSides++;
  }
  if (cell.west) {
    numSides++;
  }
  return numSides == 4;
}