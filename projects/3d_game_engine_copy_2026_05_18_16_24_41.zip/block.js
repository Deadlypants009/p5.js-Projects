class Block {
  constructor(isBlock, size, x, y, z) {
    
    this.pos = createVector(x, y, z);
    this.size = size;
    this.isBlock = isBlock;
    this.ang = createVector(0, 0, 0);
    
  }
  
  show() {
    if (this.isBlock) {
      push();
      translate(this.pos);
      rotateX(this.ang.x);
      rotateY(this.ang.y);
      rotateZ(this.ang.z);
      box(this.size);
      pop();
    }
  }
}