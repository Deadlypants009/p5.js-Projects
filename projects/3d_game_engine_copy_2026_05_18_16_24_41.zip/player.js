class Player {
  
  constructor(x, y, z, s) {
    
    this.pos = createVector(x, y, z);
    this.vel = createVector(0, 0, 0)
    this.acc = createVector(0, 0, 0);
    this.size = s;
    this.movingForce = 0.4;
    
  }
  
  show() {
    
    push();
    translate(this.pos);
    fill(0, 0, 255);
    stroke(0);
    box(this.size);
    pop();
    
  }
  
  
  update() {
    
    this.applyForce(gravity);
    
    this.vel.add(this.acc);
    this.pos.add(this.vel);
    
    this.acc.set(0);
    this.vel.mult(friction);
    
    
    for (let i = 0; i < blocks.length; i ++) {
      for (let j = 0; j < blocks[0].length; j++) {
        for (let k = 0; k < blocks[0][0].length; k++) {
          if (blocks[i][j][k].isBlock) {
            checkOverlap(player, blocks[i][j][k]);
          }
        }
      }
    }
    
  }
  
  applyForce(force) {
    this.acc.add(force);
  }
  
}