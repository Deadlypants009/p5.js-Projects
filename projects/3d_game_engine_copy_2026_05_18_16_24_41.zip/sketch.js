let blocks;
let player;
let cam;
let camX, camY;

let rows = 16;
let cols = 16;
let depth = 16;
let w = 20;
let friction = 0.9;
let gravity = 0.5;


function setup() {
  createCanvas(windowWidth, windowHeight, WEBGL);
  
  cam = createCamera();
      
  gravity = createVector(0, gravity, 0);
    
  blocks = create3DArray(rows, cols, depth);
  
  for (let i = 0; i < rows; i++) {
    for (let j = 0; j < cols; j++) {
      for (let k = 0; k < depth; k++) {
        blocks[i][j][k] = new Block(false, w, i * w, j * w, k * w);
        if (j == 0) {
          blocks[i][j][k].isBlock = true;
        }
      }
    }
  }
  
  player = new Player(40, -40, 40, 20);
  
  fill(0);
  stroke(0, 230, 180);
  strokeWeight(2);
}

function draw() {
  background(255);
  
  cam.camera(player.pos.x, player.pos.y - w, player.pos.z, camX, camY, 0, 0, 1, 0);
  
  // debugMode(500, 25);
  // orbitControl();
  
  playerInput();
  
  for (let i = 0; i < blocks.length; i ++) {
    for (let j = 0; j < blocks[0].length; j++) {
      for (let k = 0; k < blocks[0][0].length; k++) {
        blocks[i][j][k].show();
      }
    }
  }
  
  player.update();
  player.show();
  
}



function playerInput() {
  
  if (keyIsDown(RIGHT_ARROW)) {
    let force = createVector(player.movingForce, 0, 0);
    player.applyForce(force);
  }
  if (keyIsDown(LEFT_ARROW)) {
    let force = createVector(-player.movingForce, 0, 0);
    player.applyForce(force);
  }
  if (keyIsDown(UP_ARROW)) {
    let force = createVector(0, 0, -player.movingForce);
    player.applyForce(force);
  }
  if (keyIsDown(DOWN_ARROW)) {
    let force = createVector(0, 0, player.movingForce);
    player.applyForce(force);
  }
  
  camX = map(mouseX, 0, width, 0, 200);
  camY = map(mouseY, 0, height, 0, 200) - 100;
  
}



function checkOverlap(box1, box2) {
  // find the sides of the two boxes
  let left1 = box1.pos.x - box1.size / 2;
  let right1 = box1.pos.x + box1.size / 2;
  let top1 = box1.pos.y - box1.size / 2;
  let bottom1 = box1.pos.y + box1.size / 2;
  let near1 = box1.pos.z - box1.size / 2;
  let far1 = box1.pos.z + box1.size / 2;

  let left2 = box2.pos.x - box2.size / 2;
  let right2 = box2.pos.x + box2.size / 2;
  let top2 = box2.pos.y - box2.size / 2;
  let bottom2 = box2.pos.y + box2.size / 2;
  let near2 = box2.pos.z - box2.size / 2;
  let far2 = box2.pos.z + box2.size / 2;

  // Check for overlap
  if (
    left1 < right2 &&
    right1 > left2 &&
    top1 < bottom2 &&
    bottom1 > top2 &&
    near1 < far2 &&
    far1 > near2
  ) {
    player.pos.y = top2 - box2.size / 2;
    player.vel.y = 0;
  } else {
    return false;
  }
}



function create3DArray(rows, cols, depth) {
  let arr = [];
  for (let i = 0; i < rows; i++) {
    arr[i] = [];
    for (let j = 0; j < cols; j++) {
      arr[i][j] = [];
      for (let k = 0; k < depth; k++) {
        arr[i][j][k] = '';
      }
    }
  }
  return arr;
}


