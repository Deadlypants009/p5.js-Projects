let mouse;

function setup() {
  createCanvas(400, 400);
  
  mouse = new Vehicle(5, 0.3, 12);
}

function draw() {
  background(255, 5);
  
  mouse.applyForce(mouse.arrive(createVector(mouseX, mouseY)));
  mouse.update();
  mouse.show();
}



class Vehicle {
  constructor(maxSpeed, maxForce, r) {
    this.position = createVector(0, 0);
    this.velocity = createVector(0, 0);
    this.acceleration = createVector(0, 0);
    
    this.maxForce = maxForce;
    this.maxSpeed = maxSpeed;
    this.radius = r;
  }
  
  applyForce(force) {
    this.acceleration.add(force);
  }
  
  update() {
    this.velocity.add(this.acceleration);
    this.velocity.limit(this.maxSpeed);
    this.position.add(this.velocity);
    
    this.acceleration.set(0);
  }
  
  arrive(target) {
    
    let force = p5.Vector.sub(target, this.position);
    let r = 100;
    let d = force.mag();
    force.setMag(this.maxSpeed);
    if (d < r) {
      
      let m = map(d, 0, r, 0, this.maxSpeed);
      force.setMag(m);
      
    } else {
      
      force.setMag(this.maxSpeed);
      
    }
    force.sub(this.velocity);
    force.limit(this.maxForce);
    return force;
  }
  
  show() {
    fill(0);
    noStroke();
    circle(this.position.x, this.position.y, this.radius * 2);
  }
}