function setup() {
  createCanvas(400, 400);
  
  background(255);
    
  drawCircle(width / 2, height / 2, height / 2);
  
}

function draw() {
}

function drawCircle(x, y, d) {
  
  fill(y, 50, x, map(d, 0, width / 2, 0, 255) + 35);  
  circle(x, y, d);
  
  if (d > 10) {
    
    drawCircle(x + d / 2, y, d / 2);
    drawCircle(x - d / 2, y, d / 2);
    drawCircle(x, y + d / 2, d / 2);
    drawCircle(x, y - d / 2, d / 2);
    
    let newd = d / 2;
    let newx = x;
    let newy = y;
    drawCircle(newx, newy, newd);
    
  }
  
}