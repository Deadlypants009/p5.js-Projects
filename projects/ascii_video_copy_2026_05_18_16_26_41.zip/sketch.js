let bright = 'Ñ@#W$98765433210?!abc;:+=-,._ ';
let extraBrightness = 0;

let img;
let imgPath = "fish.jpg";

let arr = [];

function preload() {
  img = loadImage(imgPath);
}

function setup() {
  
  createCanvas(img.width, img.height);
  
  background(0);
  
  img.loadPixels();
  
  let w = height / img.width;
  let h = width / img.height;
  
  for (let y = 0; y < img.height; y+=8) {
    let string = '';
    for (let x = 0; x < img.width; x+=8) {
      
      let i = (x + y * img.width) * 4;
      
      let r = img.pixels[i + 0];
      let g = img.pixels[i + 1];
      let b = img.pixels[i + 2];
      
      let avg = (r + g + b) / 3 + extraBrightness;
      
      let l = floor(map(avg, 0, 255 + extraBrightness, bright.length, 0));
      
      // fill(constrain(r + extraBrightness, 0, 255), constrain(g + extraBrightness, 0, 255), constrain(b + extraBrightness, 0, 255));
      fill(255);
      let character = bright.charAt(l);
      text(character, x * (w + 0.5), y * (h + 0.5));
      
      arr.push(character);
      
      string = string + character;
      
    }
    console.log(string);
  } 
  
}

function draw() {
  
  
}