let board = [
  ["", "", ""],
  ["", "", ""],
  ["", "", ""],
];

let available = [];
let canvasSize = 300;

let gridSize = canvasSize / 3;

let players = ["x", "o"];
let currentPlayer = 0;
let winner;

function setup() {
  createCanvas(canvasSize, canvasSize + 100);
}

function nextTurn() {
  currentPlayer = (currentPlayer + 1) % 2;
}

function equal(a, b, c) {
  if (a == b && b == c) {
    return true;
  }
}

function checkWin(board) {
  //horizontal
  for (let i = 0; i < 2; i++) {
    if (equal(board[i][0], board[i][1], board[i][2])) {
      return board[i][0];
    }
  }

  //vertical
  for (let i = 0; i < 2; i++) {
    if (equal(board[0][i], board[1][i], board[2][i])) {
      return board[0][i];
    }
  }

  //diagonal
  if (equal(board[0][0], board[1][1], board[2][2])) {
    return board[0][0];
  }
  if (equal(board[2][0], board[1][1], board[0][2])) {
    return board[2][0];
  }
}

function draw() {
  background(255);

  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 3; j++) {
      let spot = board[i][j];

      //draw X
      if (spot == players[0]) {
        line(j * gridSize, i * gridSize, (j + 1) * gridSize, (i + 1) * gridSize);
        line((j + 1) * gridSize, i * gridSize, j * gridSize, (i + 1) * gridSize);
      }

      //draw O
      if (spot == players[1]) {
        ellipseMode(CENTER);
        ellipse((j + 0.5) * gridSize, (i + 0.5) * gridSize, gridSize);
      }

      mX = ceil(mouseX / gridSize) - 1;
      mY = ceil(mouseY / gridSize) - 1;

      //placing x and o
      if (
        mouseIsPressed &&
        mouseX < width &&
        mouseX > 0 &&
        mouseY < height - 100 &&
        mouseY > 0
      ) {
        if (board[mY][mX] == "") {
          if (currentPlayer == 0) {
            board[mY][mX] = "x";
            nextTurn();
          } else if (currentPlayer == 1) {
            board[mY][mX] = "o";
            nextTurn();
          }
        }
      }
    }
  }

  if (checkWin(board) == "x") {
    textSize(40);
    text("X wins", 0, canvasSize + 65);
    noLoop();
  }
  if (checkWin(board) == "o") {
    textSize(40);
    text("O wins", 0, canvasSize + 65);
    noLoop();
  }

  //board
  strokeWeight(4);
  line(gridSize * 1, 0, gridSize * 1, gridSize * 3);
  line(gridSize * 2, 0, gridSize * 2, gridSize * 3);
  line(0, gridSize * 1, gridSize * 3, gridSize * 1);
  line(0, gridSize * 2, gridSize * 3, gridSize * 2);
  line(0, gridSize * 3, gridSize * 3, gridSize * 3);

  strokeWeight(1);
}
