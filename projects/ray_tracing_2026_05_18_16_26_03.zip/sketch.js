let source;

let objects = [];

let mode = 'adjust';

let numLinesSlider;

let modeSwitchButton;
let newWallButton;

let iterationDistSlider;
let iterationDist = 5;

function setup() {
  createCanvas(400, 400);
  
  numLinesSlider = createSlider(1, 1000, 12, 1);
  
  iterationDistSlider = createSlider(1, 25, iterationDist, 1);
  
  modeSwitchButton = createButton('Switch Mode');
  newWallButton = createButton('New Wall');
  
  objects.push(new Wall(width / 2 - 50, height / 2 - 50, 100, 100));   
  
  source = {
    x: width / 2,
    y: height / 2
  }
}

function draw() {
  background(0);
  
  // print(deltaTime);
  
  iterationDist = iterationDistSlider.value();
  
  modeSwitchButton.mousePressed(() => {
    if (mode == 'adjust') {mode = 'run';} else {mode = 'adjust';}
  });
  newWallButton.mousePressed(() => {
    objects.push(new Wall(width / 2 - 50, height / 2 - 50, 100, 100));   
  });
  
  source.x = mouseX;
  source.y = mouseY;
  
  if (mode == 'run') {
    rayTrace();
  }
  
  for (let i = 0; i < objects.length; i++) {
    objects[i].update();
    objects[i].show();
  }
  
}

function collides(rect1, point1) {
  return (
    rect1.x < point1.x &&
    rect1.x + rect1.w > point1.x &&
    rect1.y < point1.y &&
    rect1.y + rect1.h > point1.y
  );
}

function calDist(i) {
  
  let closestDist = width * 1.5;
    
  for (let j = 0; j < objects.length; j++) {
    for (let k = 0; k < height * 1.5; k += iterationDist) {
      
      let pt = {
        x: source.x + cos(i) * k,
        y: source.y + sin(i) * k
      }
      
      if (collides(objects[j], pt)) {
        if (k < closestDist) {
          closestDist = k;
        }
      }
    }
  }
  
  
  
  return closestDist;
}

function clamp(value, small, large) {
  
  if (value > large) {
    value = large;
  }
  if (value < small) {
    value = small;
  }
  
  return value;
}

function rayTrace() {
  
  fill(255);
  
  beginShape();
  
  for (let i = 0; i < TWO_PI; i += PI / numLinesSlider.value()) {
    
    let pt = {
      x: cos(i) * calDist(i),
      y: sin(i) * calDist(i)
    }
       
    // vertex(clamp(source.x + pt.x, 0, 400), clamp(source.y + pt.y, 0, 400));
    
    stroke(255);
    strokeWeight(1);
    line(source.x, source.y, source.x + pt.x, source.y + pt.y);
    
  }
  
  endShape(CLOSE);
  
}

function keyPressed() {
  if (keyCode == 32) {
    if (mode == 'run') {
      mode = 'adjust';
    } else {
      mode = 'run';
    }
  }
  
  if (keyCode == 13) {
    objects.push(new Wall(width / 2 - 50, height / 2 - 50, 100, 100));   
  }
}

function mouseReleased() {
  for (let i = 0; i < objects.length; i++) {
    for (let j = 0; j < objects[i].draggers.length; j++) {
      objects[i].draggers[j].pressed = false;
    }
  }
}