class Wall {
  constructor(x, y, w, h) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.draggers = [
      new Dragger(this.x + this.w / 2, this.y, 'vertical'), //top
      new Dragger(this.x + this.w, this.y + this.h / 2, 'horizontal'), //right
      new Dragger(this.x + this.w / 2, this.y + this.h, 'vertical'), //bottom
      new Dragger(this.x, this.y + this.h / 2, 'horizontal') // left
    ];
  }
  
  show() {
    noStroke();
    fill(100);
    rect(this.x, this.y, this.w, this.h);
    
    if (mode == 'adjust') {
      for (let i = 0; i < this.draggers.length; i++) {
        this.draggers[i].show();
      }
    }
  }
  
  update() {
    if (mode == 'adjust') {
      for (let i = 0; i < this.draggers.length; i++) {
        this.draggers[i].update();
        if (this.draggers[i].direction == 'horizontal') {
          this.draggers[i].y = this.y + this.h / 2;
        }
        if (this.draggers[i].direction == 'vertical') {
          this.draggers[i].x = this.x + this.w / 2;
        }
      }
    
      this.y = this.draggers[0].y;
      this.h = this.draggers[2].y - this.draggers[0].y;
      this.x = this.draggers[3].x;
      this.w = this.draggers[1].x - this.draggers[3].x;
    
    }
  }
}