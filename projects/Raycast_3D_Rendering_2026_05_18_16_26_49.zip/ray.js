class Ray {
  constructor(x1, y1, dir) {
    this.x1 = x1;
    this.y1 = y1;
    this.originalDir = dir;
    this.dir = dir + playerDir;
    
    this.maxLength = 1000;
    
    this.length = this.maxLength;
    
  }
  
  collide() {
    
    this.length = this.maxLength;
    
    for (let wall of walls) { 
      
      let x2 = playerPos.x + cos(this.dir) * this.length;
      let y2 = playerPos.y + sin(this.dir) * this.length;
      
      let intersection = lineIntersection(this.x1, this.y1, x2, y2, wall.x1, wall.y1, wall.x2, wall.y2);
      
      if (intersection) {
        
        // fill(255, 0, 0);
        // circle(intersection.x, intersection.y, 8);
        
        this.length = dist(this.x1, this.y1, intersection.x, intersection.y);
                
      }
      
    }
  }
  
  
  show() {
    
    stroke(255);
    let x2 = playerPos.x + cos(this.dir) * this.length;
    let y2 = playerPos.y + sin(this.dir) * this.length;
    line(this.x1, this.y1, x2, y2);
    
  }
  
}