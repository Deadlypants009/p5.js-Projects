let walls = [];

let rays = [];

let playerPos;
let playerDir;

let playerTurnSpeed = 0.05;
let playerSpeed = 1;
let playerSize = 12;

let playerFOV = 95;

let rayInterval = 5;

function setup() {
  createCanvas(400, 400);
  
  playerFOV = radians(playerFOV);
  rayInterval = radians(rayInterval);
  
  playerPos = createVector(width / 2, height / 2);
  playerDir = 0;
  
  addRays();
  
  walls.push(new Wall(100, 100, 300, 100));
}

function draw() {
  background(0);
  
  for (let wall of walls) {
    wall.show();
  }
  
  for (let ray of rays) {
    ray.collide();
    ray.show();
  }
  
  updateRays();
  
  drawPlayer();
  
  if (keyIsDown(RIGHT_ARROW)) {
    playerDir += playerTurnSpeed;
  }
  if (keyIsDown(LEFT_ARROW)) {
    playerDir -= playerTurnSpeed;
  }
  if (keyIsDown(UP_ARROW)) {
    playerPos.add(p5.Vector.fromAngle(playerDir + PI / 2).setMag(playerSpeed));
  }
  if (keyIsDown(DOWN_ARROW)) {
    playerPos.sub(p5.Vector.fromAngle(playerDir + PI / 2).setMag(playerSpeed));
  }
  
}

function addRays() {
  
  for (let i = 0; i < playerFOV; i += rayInterval) {
    
    rays.push(new Ray(playerPos.x, playerPos.y, i + PI / 4));
    
  }
  
}

function updateRays() {
  
  for (let ray of rays) {
    
    ray.x1 = playerPos.x;
    ray.y1 = playerPos.y;
    
    ray.dir = ray.originalDir + playerDir;
    
  }
  
}


function drawPlayer() {
  
  push();
  translate(playerPos);
  rotate(playerDir);
  fill(255);
  triangle(-playerSize, -playerSize, playerSize, -playerSize, 0, playerSize);
  pop();
  
}




function lineIntersection(x1, y1, x2, y2, x3, y3, x4, y4) {

    // Check if none of the lines are of length 0
    if ((x1 === x2 && y1 === y2) || (x3 === x4 && y3 === y4)) {
        return false;
    }

    const denominator = ((y4 - y3) * (x2 - x1) - (x4 - x3) * (y2 - y1));

    // Lines are parallel
    if (denominator === 0) {
        return false;
    }

    let ua = ((x4 - x3) * (y1 - y3) - (y4 - y3) * (x1 - x3)) / denominator;
    let ub = ((x2 - x1) * (y1 - y3) - (y2 - y1) * (x1 - x3)) / denominator;

    // is the intersection along the segments
    if (ua < 0 || ua > 1 || ub < 0 || ub > 1) {
        return false;
    }

    // Return a object with the x and y coordinates of the intersection
    let x = x1 + ua * (x2 - x1);
    let y = y1 + ua * (y2 - y1);

    return { x, y }
}