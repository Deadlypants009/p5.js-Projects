let nn;

let inputs = [1, 2, 3, 4, 5];

let numInputs = 5;
let numHidden = 10;
let numOutputs = 2;

let numInputSlider;
let numHiddenSlider;
let numOutputSlider;

function setup() {
  createCanvas(400, 400);
  
  numInputSlider = createSlider(1, 100, 3, 1);
  numHiddenSlider = createSlider(1, 100, 10, 1);
  numOutputSlider = createSlider(1, 100, 2, 1);
  
}

function draw() {
  background(255);
  
  numInputs = numInputSlider.value();
  numHidden = numHiddenSlider.value();
  numOutputs = numOutputSlider.value();
  
  drawNN(0, 0, 200, 200, 8, numInputs, numHidden, numOutputs);
}



function drawNN(x, y, w, h, d, numInputs, numHidden, numOutputs) {
  fill(0);
  
  translate(x, y);
  
  let inputHeight = h / numInputs;
  for (let i = 0; i < numInputs; i++) {
    let x = w / 4;
    let y = inputHeight * i + inputHeight / 2;
    circle(x, y, d);
    let hiddenHeight = h / numHidden;
    for (let j = 0; j < numHidden; j++) {
      line(x, y, w / 2, hiddenHeight * j + hiddenHeight / 2);
    }
  }
  let hiddenHeight = h / numHidden;
  for (let i = 0; i < numHidden; i++) {
    let x = w / 2;
    let y = hiddenHeight * i + hiddenHeight / 2;
    circle(x, y, d);
    let outputHeight = h / numOutputs;
    for (let i = 0; i < numOutputs; i++) {
      line(x, y, 3 * w / 4, outputHeight * i + outputHeight / 2);
    }
  }
  let outputHeight = h / numOutputs;
  for (let i = 0; i < numOutputs; i++) {
    circle(3 * w / 4, outputHeight * i + outputHeight / 2, d);
  }
}