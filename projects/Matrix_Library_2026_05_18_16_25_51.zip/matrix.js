class Matrix {
  constructor(rows, cols) {
    this.rows = rows;
    this.cols = cols;
    this.data = new Array(this.rows);
    
    for (let i = 0; i < this.rows; i++) {
      this.data[i] = new Array(this.cols);
      for (let j = 0; j < this.cols; j++) {
        this.data[i][j] = 0;
      }
    } 
  }
  
  
  
  randomize() {
    for (let i = 0; i < this.rows; i++) {
      for (let j = 0; j < this.cols; j++) {
        this.data[i][j] = floor(random(10));
      }
    }
  }
  
  
  static add(a, b) {
    let output = new Matrix(a.rows, a.cols);
    if (b instanceof Matrix) {
      for (let i = 0; i < a.rows; i++) {
        for (let j = 0; j < a.cols; j++) {
          output.data[i][j] = a.data[i][j] + b.data[i][j];
        }
      }
    } else { // if just b digit instead of a matrix
      for (let i = 0; i < a.rows; i++) {
        for (let j = 0; j < a.cols; j++) {
          output.data[i][j] = a.data[i][j] + b;
        }
      }
    }
    return output;
  }
  
  add(a) {
    if (a instanceof Matrix) {
      for (let i = 0; i < this.rows; i++) {
        for (let j = 0; j < this.cols; j++) {
          this.data[i][j] += a.data[i][j];
        }
      }
    } else { // if a is just a digit instead of a matrix
      for (let i = 0; i < this.rows; i++) {
        for (let j = 0; j < this.cols; j++) {
          this.data[i][j] += a;
        }
      }
    }
  }
  
  map(fn) {
    for (let i = 0; i < this.rows; i++) {
      for (let j = 0; j < this.cols; j++) {
        this.data[i][j] = fn(this.data[i][j]);
      }
    }
  }
  
  
  scalar(n) {
    for (let i = 0; i < this.rows; i++) {
      for (let j = 0; j < this.cols; j++) {
        this.data[i][j] = this.data[i][j] * n;
      }
    }
  }
  
  
  static transpose(a) {
    let output = new Matrix(a.cols, a.rows);
    for (let i = 0; i < a.rows; i++) {
      for (let j = 0; j < a.cols; j++) {
        output.data[j][i] = a.data[i][j];
      }
    }
    return output;
  }
  
  
  static matrixProduct(a, b) {
    let output = new Matrix(a.rows, b.cols);
    if (a.cols != b.rows) {
      console.log("a.cols must equal b.rows");
      return undefined;
    }
    for (let i = 0; i < output.rows; i++) {
      for (let j = 0; j < output.cols; j++) {
        let sum = 0;
        for (let k = 0; k < a.cols; k++) {
          sum += a.data[i][k] * b.data[k][j];
        }
        output.data[i][j] = sum;
      }
    }
    return output;
  }
}


function logMatrix(matrix) {
  for (let i = 0; i < matrix.rows; i++) {
    let l = "|";
    for (let j = 0; j < matrix.cols; j++) {
      l += matrix.data[i][j].toString();
      if (j < matrix.cols - 1) {
        l += ", ";
      }
    }
    l += "|";
    console.log(l);
  }
}


function fromArray(arr) {
  let output = new Matrix(arr.length, 1);
  for (let i = 0; i < arr.length; i++) {
    output.data[i][0] = arr[i];
  }
  return output;
}


function toArray(matrix) {
  let output = [];
  for (let i = 0; i < matrix.rows; i++) {
    for (let j = 0; j < matrix.cols; j++) {
      output.push(matrix.data[i][j]);
    }
  }
  return output;
}