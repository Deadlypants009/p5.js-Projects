let grid;
let w = 5;
let cols, rows;
let h = 0; 

function setup() {
  createCanvas(400, 400);
  
  colorMode(HSB);
    
  frameRate(60);
    
  cols = width / w;
  rows = height / w;
  grid = create2DArray(cols, rows);
  
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      grid[i][j] = 0;
    }
  }

}

function draw() {
  background(0);
  
  noStroke();
  
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      
      if (grid[i][j] > 0) {
        fill(grid[i][j], 255, 255);
      } else {
        fill(0);
      }
    
      rect(i * w, j * w, w, w);
      
    }
  }
  
  update();
}


function update() {
  
  let nextGen = create2DArray(cols, rows);
  
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      nextGen[i][j] = 0;
    }
  }
  
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {  
      let cell = grid[i][j];
      if (grid[i][j] > 0 && i > 0 && i < cols - 1) {
        if (grid[i][j + 1] == 0) {
          nextGen[i][j + 1] = cell;
        } else if (grid[i + 1][j + 1] == 0) {
          nextGen[i + 1][j + 1] = cell;
        } else if (grid[i - 1][j + 1] == 0) {
          nextGen[i - 1][j + 1] = cell; 
        } else if (grid[i][j + 1] == undefined || grid[i][j + 1] > 0) {
          nextGen[i][j] = cell;
        }
      }
    }
  }
  grid = nextGen;
  
  
  if (mouseIsPressed && mouseX < (cols - 1) * w && mouseX > w && mouseY < (rows - 1) * w && mouseY > w) {
    
    let mouseCol = floor(mouseX / w);
    let mouseRow = floor(mouseY / w);
  
    grid[mouseCol-1][mouseRow-1] = h;
    grid[mouseCol-1][mouseRow] = h;
    grid[mouseCol-1][mouseRow+1] = h;
    grid[mouseCol][mouseRow-1] = h;
    grid[mouseCol][mouseRow] = h;
    grid[mouseCol][mouseRow+1] = h;
    grid[mouseCol+1][mouseRow-1] = h;
    grid[mouseCol+1][mouseRow] = h;
    grid[mouseCol+1][mouseRow+1] = h;
    h++;
    if (h > 360) {
      h = 0;
    }
  }
}



function create2DArray(cols, rows) {
  
  let arr = new Array(cols);
  
  for (let i = 0; i < arr.length; i++) {
    arr[i] = new Array(rows);
  }
  return arr;
}