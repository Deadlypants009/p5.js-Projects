let video;

let saveButton;
let pauseButton;

let running = true;

let x = -45;

function setup() {
  createCanvas(320, 240);
  pixelDensity(1);
  video = createCapture(VIDEO);
  video.size(320, 240);
  background(51);
  
  saveButton = createButton('Save');
  pauseButton = createButton('Pause');
}

function draw() {
  video.loadPixels();
  // video.hide();
  let w = video.width;
  let h = video.height;
  copy(video, x, 0, 1, h, x, 0, 1, h);
  if (running) {
    x = x + 1;
  }
  if (x > width) {
    x = 0;
  }
  
  saveButton.mousePressed(() => {
    saveCanvas('splitScan');
  });
  pauseButton.mousePressed(() => {
    running = !running;
  });
}