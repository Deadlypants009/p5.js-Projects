let board = [
  ['', '', 'x', '', '', '', '', '', '',''],
  ['', '', '', '', '', 'x', '', '', '',''],
  ['', '', '', '', '', '', '', '', '',''],
  ['', '', '', '', '', '', '', '', '',''],
  ['', '', '', '', '', '', '', '', '',''],
  ['', '', '', '', '', '', '', '', '',''],
  ['', '', '', '', '', '', '', '', '',''],
  ['', 'x', 'x', '', '', '', '', '', '',''],
  ['', '', '', '', '', '', '', '', '',''],
  ['', '', '', '', '', '', '', '', '','']
];

let width = 400;
let height = 400;

let w = width / board[0].length;
let h = height / board.length;

let ball;

let strokes = 0;

let friction = 0.05;
let drag = 0.1;
let density = 0.0025;
let strength = 0.2;

function setup() {
  createCanvas(400, 400);
  
  ball = new Ball(width / 2, height / 2, 1); 
  hole = new Hole(width / 2, height - 100);
  
}

    

function draw() {
  background(255);

  drawBoard();
  
  hole.show();
  
  if (ball != 0) {
    ball.edge();
    ball.collide();
    ball.update();
    ball.show();
    ball.hole();
  }
  
}

function mousePressed() {
  if (mouseX < width && mouseX > 0 && mouseY < height && mouseY > 0 && ball != 0) {
    ball.click();
    strokes += 1;
  }
}

function keyPressed() {
  
  if (keyCode === 32) {
      ball = new Ball(mouseX, mouseY);
    }
  
}

function drawBoard() {
  
  let temp = 0;
  for (let x = 0; x < board[0].length; x++) {
    temp += 1;
    for (let y = 0; y < board.length; y++) {
      
      noStroke();
      if (temp % 2 == 0) {
        fill(145, 212, 61);
      } else {
        fill(119, 176, 48);
      }
      if (board[y][x] == 'x') {
        stroke(0);
        strokeWeight(1);
        fill(161, 52, 10);
      }
      
      rect(x * w, y * h, w, h);
      
      temp += 1;
    }
  }
}