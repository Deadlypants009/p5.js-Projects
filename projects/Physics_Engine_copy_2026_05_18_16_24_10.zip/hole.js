class Hole {
  constructor(x, y) {
   
    this.pos = createVector(x, y);
    this.r = 18;
    
  }
  
  show() {
    
    stroke(255);
    fill(0);
    ellipse(this.pos.x, this.pos.y, this.r * 2)
    
  }
}