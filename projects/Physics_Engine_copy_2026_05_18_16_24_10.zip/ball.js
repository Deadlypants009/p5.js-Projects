class Ball {
  
  constructor(x, y, m) {
    this.m = m;
    this.r = Math.sqrt(this.m * 200);
    this.acc = createVector(0, 0);
    this.vel = createVector(0, 0);
    this.force = createVector(0, 0);
    this.pos = createVector(x, y);  
  }
  
  update() {
    
    this.drag();
    this.acc.add(this.force);
    this.vel.add(this.acc);
    this.pos.add(this.vel);
    
    this.force.set(0, 0);
    this.acc.set(0, 0);
    
    this.friction();
    
  }
  
  applyForce(force) {
    this.acc.add(p5.Vector.div(force, this.m));
  }
  
  friction() {
    
    let f = this.vel.copy();
    f.mult(-1);
    f.normalize();
    f.setMag(friction);
    
    this.applyForce(f);
  }
  
  drag() {
    
    let area = (2 * PI * this.r) / 2;
    
    let d = this.vel.copy();
    d.mult(-1);
    d.normalize();
    
    let v = this.vel.magSq();
    
    d.setMag(v * (1/2) * area * drag * density);
    
    this.applyForce(d);
    
  }
  
  edge() {
    if (this.pos.y > height - this.r) {
      this.pos.y = height - this.r;
      this.vel.y *= -1;
    }
    if (this.pos.y < this.r) {
      this.pos.y = this.r;
      this.vel.y *= -1;
    }
    if (this.pos.x > width - this.r) {
      this.pos.x = width - this.r;
      this.vel.x *= -1;
    }
     if (this.pos.x < this.r) {
      this.pos.x = this.r;
      this.vel.x *= -1;
    }
  }
  
  
  show() {
    
    fill(255);
    strokeWeight(2);
    stroke(0);
    ellipse(this.pos.x, this.pos.y, this.r * 2);
    
  }
  
  click() {
    
    let mouseV = createVector(mouseX, mouseY);
     
    let dir = p5.Vector.sub(this.pos, mouseV);
    
    dir.limit(70);
     
    stroke(0);
    fill(0);
    line(this.pos.x, this.pos.y, dir.x, dir.y);
    
    this.applyForce(dir.mult(strength));
  }
  
  collide() {
    
     for (let y = 0; y < board.length; y++) {
       for (let x = 0; x < board[0].length; x ++) {
         if (board[y][x] == 'x') {
           if (this.pos.x > x * w && this.pos.x < x * w + w && this.pos.y > y * h && this.pos.y < y * h + h) {
            
             this.vel.mult(-1);
             
           }
         }
       }
     } 
  } 
  
  hole() {
    
    if (this.pos.x > hole.pos.x - hole.r && this.pos.x < hole.pos.x + hole.r && this.pos.y > hole.pos.y - hole.r && this.pos.y < hole.pos.y + hole.r) {
      
      ball = 0;
      
    }
  }
  
}