// press 'S' to save image

let grid = [];

let layer0Count = 6;
let layer1Count = 20;
let layer2Count = 100;

let modulousCount = 6;

let layer0Position, layer1Position, layer2Position;

function setup() {
  createCanvas(384, 216);
  
  layer0Position = floor(height / 3);
  layer1Position = floor((height / 3) * 2);
  layer2Position = floor((height / 3) * 3);
  
  background(0);
  
  fill(255);
  noStroke();
  
  let x = 0;
  
  for (let i = 0; i < width; i++) {
    for (let j = 0; j < height; j++) {
      if (j < layer0Position) {
        if (floor(random(layer0Count)) == 0 && x % modulousCount == 0) {
          rect(i, j, 1, 1);
        }
      } else if (j < layer1Position) {
        if (floor(random(layer1Count)) == 0 && x % modulousCount == 0) {
          rect(i, j, 1, 1);
        }
      } else {
        if (floor(random(layer2Count)) == 0 && x % modulousCount == 0) {
          rect(i, j, 1, 1);
        }
      }
      x++;
    }
    x++;
  }
}


function keyPressed() {
  if (keyCode == 83) {
    saveCanvas("background");
  }
}