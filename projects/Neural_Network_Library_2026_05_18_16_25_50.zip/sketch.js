let nn;

let inputs = [1, 2, 3, 4, 5];


function setup() {
  createCanvas(400, 400);
  
  nn = new NeuralNetwork(5, 10, 2);
}

function draw() {
  background(255);  
}