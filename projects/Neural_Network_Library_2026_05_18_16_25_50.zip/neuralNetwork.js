class NeuralNetwork {
  constructor(inputSize, hiddenSize, outputSize) {
    this.inputSize = inputSize;
    this.hiddenSize = hiddenSize;
    this.outputSize = outputSize;
    
    this.weights_ih = new Matrix(this.hiddenSize, this.inputSize);
    this.weights_ho = new Matrix(this.outputSize, this.hiddenSize);
    
    this.weights_ih = Matrix.randomize(this.weights_ih);
    this.weights_ho = Matrix.randomize(this.weights_ho);
    
    this.bias_h = new Matrix(this.hiddenSize, 1);
    this.bias_o = new Matrix(this.outputSize, 1);
    
    this.bias_h = Matrix.randomize(this.bias_h);
    this.bias_o = Matrix.randomize(this.bias_o);

  }
  
  
  
  feedForward(input_array) {
    
    let inputs = fromArray(input_array);
    
    let hidden = Matrix.matrixProduct(this.weights_ih, inputs);
    hidden = Matrix.add(hidden, this.bias_h);
    
    hidden = Matrix.map(hidden, sigmoid);
    
    let output = Matrix.matrixProduct(this.weights_ho, hidden);
    output = Matrix.add(output, this.bias_o);
    
    output = Matrix.map(output, sigmoid);
    
    output = toArray(output);
    return output;
    
  }
}


function sigmoid(x) {
  return 1 / (1 + Math.exp(-x));
}