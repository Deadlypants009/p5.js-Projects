class Pendulum {
  
  constructor(originx, originy, len, a, m) {
    
    this.angle = a;
    this.angleV = 0;
    this.angleA = 0;
    this.m = m;
    
    this.origin = createVector(originx, originy);    
    this.len = len;
    
    let bobx = this.origin.x + (sin(this.angle) * this.len);
    let boby = this.origin.y + (cos(this.angle) * this.len);
    
    this.bob = createVector(bobx, boby);
    
  }
  
  show() {
    
    stroke(255);
    strokeWeight(5);
    fill(255, 101, 200);
    
    line(this.origin.x, this.origin.y, this.bob.x, this.bob.y);
    
    strokeWeight(3);
    
    circle(this.bob.x, this.bob.y, this.m * 8);
    
  }
  
  update() {
    
    this.bob.x = this.origin.x + sin(this.angle) * this.len;
    this.bob.y = this.origin.y + cos(this.angle) * this.len;
    
    let gP = (sin(this.angle) * gravity) / this.len;
    
    this.applyForce(gP);
    
    this.angleV += this.angleA;
    this.angle += this.angleV;
    
    this.angleA = 0;
    
    this.angleV *= resistance;
    
  }
  
  applyForce(force) {
    
    this.angleA = -1 * force;
    
  }
}