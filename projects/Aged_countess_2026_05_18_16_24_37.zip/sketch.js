let pendulum;
let gravity = 0.5;
let resistance = 1;

let path = [];

function setup() {
  createCanvas(600, 400);
  
  pendulum0 = new Pendulum(width / 2, height / 2, random(70, 100), random(TWO_PI * 2), 5);
  pendulum1 = new Pendulum(pendulum0.bob.x, pendulum0.bob.y, random(50, 70), random(TWO_PI), 5);
  
}

function draw() {
  background(100, 201, 225);
  
  pendulum0.show();
  pendulum0.update();
  pendulum1.show();
  pendulum1.origin.x = pendulum0.bob.x;
  pendulum1.origin.y = pendulum0.bob.y;
  pendulum1.update();

}