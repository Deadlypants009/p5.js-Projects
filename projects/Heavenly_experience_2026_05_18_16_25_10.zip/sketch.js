let d = 0.02;
let t = 0;
let point1;
let point2;
let point3;
let point4;

function setup() {
  createCanvas(400, 400);
  
  colorMode(HSB);
    
  point1 = new Dragger(0, height / 2);
  point2 = new Dragger(width / 3, height / 3);
  point3 = new Dragger(width / 3 * 2, height / 3 * 2);
  point4 = new Dragger(width, height / 2);
}

function draw() {
  background(0);
    
  for (let t = 0; t < 1; t += d) {
    
    fourLerp(point1.pos, point2.pos, point3.pos, point4.pos, t);
    
  }
  
  point1.show();
  point2.show();
  point3.show();
  point4.show();
  point1.update();
  point2.update();
  point3.update();
  point4.update();
  
}


function fourLerp(point1, point2, point3, point4, t) {
  
  let x = lerp(quadraticLerp(point1, point2, point3, t).x, quadraticLerp(point2, point3, point4, t).x, t);    
  let y = lerp(quadraticLerp(point1, point2, point3, t).y, quadraticLerp(point2, point3, point4, t).y, t);    
  
  return createVector(x, y);
}

function quadraticLerp(point1, point2, point3, t) {
  
  let a = linearLerp(point1, point2, t);
  let b = linearLerp(point2, point3, t);
  return linearLerp(a, b, t);
  
}

function linearLerp(point1, point2, t) {
  
  let x = lerp(point1.x, point2.x, t);
  let y = lerp(point1.y, point2.y, t);
  
  stroke(map(t, 0, 1, 0, 360), 100, 100);
  line(point1.x, point1.y, point2.x, point2.y);
  
  return createVector(x, y);
}



class Dragger {
  
  constructor(x, y) {
    this.pos = createVector(x, y);
    this.radius = 8;
    this.mouseOver = false;
    this.pressed = false;
  }
  
  show() {
    
    if (this.mouseOver) {
      fill(75);
    } else {
      fill(255);
    }
    noStroke();
    circle(this.pos.x, this.pos.y, this.radius * 2);
    
  }
  
  update() {
    
    if (dist(mouseX, mouseY, this.pos.x, this.pos.y) < this.radius) {
      this.mouseOver = true;
    } else {
      this.mouseOver = false;
    }
    
    if (mouseIsPressed && this.mouseOver) {
      this.pressed = true;
    }
    
    if (this.pressed) {
      let mousePos = createVector(mouseX, mouseY);
      this.pos.set(mousePos);
    }
    
  }
  
}


function mouseReleased() {
  
  point1.pressed = false;
  point2.pressed = false;
  point3.pressed = false;
  point4.pressed = false;
  
}