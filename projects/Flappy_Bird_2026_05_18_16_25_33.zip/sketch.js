let player;
let pipes = [];

let gravity;

let running = false;
let dead = false;

let openingWidth = 150;

function setup() {
  createCanvas(400, 400);
  
  player = new Player(100, height / 2);
  pipes.push(new Pipe(width, random(openingWidth, height - openingWidth)));
  pipes.push(new Pipe(width * 1.75, random(openingWidth, height - openingWidth)));
  
  gravity = createVector(0, 0.5);
}

function draw() {
  background(149, 230, 245);
  
  if (running) {
    player.update();
    for (let i = 0; i < pipes.length; i++) {
      pipes[i].update();
      if (pipes[i].x + 40 < 0) {
        pipes.splice(i, 1);
        pipes.push(new Pipe(width * 1.25, random(openingWidth, height - openingWidth)));
      }
    }
  }
  
  player.show();
  for (let pipe of pipes) {
    pipe.show();
    if (collides(player, pipe.rect1) || collides(player, pipe.rect2)) {
      death();
    }
    if (player.pos.y < -player.h || player.pos.y > height) {
      death();
    }
  }
  
  if (!running) {
    background(50, 150);
    textAlign(CENTER);
    fill(0);
    textSize(32);
    text('Click To Play', width / 2, height / 2);
  }
}

function reset() {
  pipes = [];
  pipes.push(new Pipe(width, random(openingWidth, height - openingWidth)));
  pipes.push(new Pipe(width * 1.75, random(openingWidth, height - openingWidth)));
  player.pos.y = height / 2;
  running = true;
  dead = false;
}

function death() {
  dead = true;
  running = false;
}

function collides(rect1, rect2) {
  return (
    rect1.pos.x < rect2.x + rect2.w &&
    rect1.pos.x + rect1.w > rect2.x &&
    rect1.pos.y < rect2.y + rect2.h &&
    rect1.pos.y + rect1.h > rect2.y
  );
}

function mousePressed() {
  if (dead) {
    reset();
  } else {
    running = !running;
  }
}