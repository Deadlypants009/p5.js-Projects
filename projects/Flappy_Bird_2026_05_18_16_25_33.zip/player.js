class Player {
  constructor(x, y) {
    this.pos = createVector(x, y);
    this.vel = createVector();
    this.acc = createVector();
    this.w = 32;
    this.h = 32;
    this.jumpForce = -5;
  }

  update() {
    if (keyIsDown(32)) {
      this.vel.y = this.jumpForce;
    }

    this.applyForce(gravity);

    this.vel.add(this.acc);
    this.vel.limit(14);
    this.pos.add(this.vel);

    this.acc.set(0);
  }

  show() {
    fill(247, 240, 30);
    stroke(0);
    rect(this.pos.x, this.pos.y, this.w, this.h);
  }

  applyForce(force) {
    this.acc.add(force);
  }
}
