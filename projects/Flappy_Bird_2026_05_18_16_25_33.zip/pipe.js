class Pipe {
  constructor(x, opening) {
    
    this.x = x;
    this.openingPos = opening;
    this.rect1 = {
      x: this.x,
      y: 0,
      w: 40,
      h: height - this.openingPos - openingWidth
    };
    this.rect2 = {
      x: this.x,
      y: height - this.openingPos,
      w: 40,
      h: height
    };
    
  }
  
  update() {
    this.x--;
    this.rect1.x = this.x;
    this.rect2.x = this.x;
  }
  
  show() {
    
    stroke(0);
    strokeWeight(2);
    fill(0, 255, 0);
    rect(this.rect1.x, this.rect1.y, this.rect1.w, this.rect1.h);
    
    rect(this.rect2.x, this.rect2.y, this.rect2.w, this.rect2.h);
    
  }
}