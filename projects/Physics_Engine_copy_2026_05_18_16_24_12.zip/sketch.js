let attractor;
let balls = [];
let numBalls = 5;

let grav = 5;

function setup() {
  createCanvas(1000, 1000);
  for (let i = 0; i < numBalls; i++) {
    balls.push(new Ball(random(0, 100), random(width), random(1, 5))); 
    balls[i].applyForce(createVector(random(4), random(4)));
  }
  attractor = new Attractor(width / 2, height / 2, 100);
  
  background(25);
} 

function draw() {

  attractor.show();
  for (let i = 0; i < balls.length; i++) {
    attractor.gravity(balls[i]);
    balls[i].update();
    balls[i].show();
  }
  
}

function mousePressed() {
  background(25);
  
}



class Ball {
  
  constructor(x, y, m) {
    this.m = m;
    this.r = sqrt(this.m) * 10;
    this.acc = createVector(0, 0);
    this.vel = createVector(10, 0);
    this.force = createVector(0, 0);
    this.pos = createVector(x, y);  
  }
  
  update() {
    
    this.acc.add(this.force);
    this.vel.add(this.acc);
    this.pos.add(this.vel);
    
    this.force.set(0, 0);
    this.acc.set(0, 0);
    
  }
  
  applyForce(force) {
    this.acc.add(p5.Vector.div(force, this.m));
  }
  
  
  show() {
    
    strokeWeight(2);
    stroke(255, 0, 0);
    noFill();
    ellipse(this.pos.x, this.pos.y, this.r * 2);
    
  }
}



class Attractor {
  constructor(x, y, m) {
    this.pos = createVector(x, y);
    this.m = m;
    this.r = sqrt(this.m) * 10;
    
    
  }
  
  show() {
    
    fill(255, 191, 38);
    stroke(0);
    ellipse(this.pos.x, this.pos.y, this.r * 2);
    
  }
  
  gravity(object) {
    
    let dir = p5.Vector.sub(this.pos, object.pos);
    let d = constrain(dir.mag(), 5, 50);
    
    let f = ((this.m * object.m) / (d * d)) * grav;
    
    dir.setMag(f);
    
    object.applyForce(dir);
    
    
  }
}