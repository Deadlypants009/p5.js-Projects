let block;

function setup() {
  createCanvas(400, 400, WEBGL);
  
  block = new Block(100, 0, 0, 0);
  
  noFill();
  stroke(0, 255, 0);
  strokeWeight(2);
}

function draw() {
  background(0);
  
  // debugMode();
  orbitControl();

  block.show();
  
  block.ang.x += 0.01;
  block.ang.y += 0.01;
  block.ang.z += 0.01;

}

function keyPressed() {
  if (key === 's') {
    saveGif('mySketch', 5);
  }
}


class Block {
  constructor(size, x, y, z) {
    
    this.pos = createVector(x, y, z);
    this.size = size;
    this.ang = createVector(0, 0, 0);
    
  }
  
  show() {
    
    push();
    translate(this.pos);
    rotateX(this.ang.x);
    rotateY(this.ang.y);
    rotateZ(this.ang.z);
    box(this.size);
    pop();
    
  }
}