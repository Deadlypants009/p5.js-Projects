class Population {
  constructor(t, m, p) {
    this.mutation = m;
    this.populationAmt = p;
    this.target = t;
    this.maxFitness = 0;
    
    this.matingPool = [];
    
    this.popArr = [];
    for (let i = 0; i < this.populationAmt; i++) {
      this.popArr[i] = new DNA(this.target.length); 
      
    }
  }
  
  calFitness() {
    for (let i = 0; i < this.popArr.length; i++) {
      for (let j = 0; j < this.target.length; j++) {
        if (this.popArr[i].letters[j] == Array.from(this.target[j])) {
          this.popArr[i].fitness += 1 / this.target.length;
          
        }
      }
      
      if (this.popArr[i].fitness > this.maxFitness) {
        this.maxFitness = this.popArr[i].fitness;
        this.bestDNA = this.popArr[i]; 
        
      }
    }
  }
  
  fillPool() {
    this.matingPool = [];
    let k = 0;
    for (let i = 1; i < this.populationAmt; i++) {
      for (let j = 1; j < ceil(this.popArr[i].fitness * 10) + 1; j++) {
        this.matingPool[k] = this.popArr[i];
        k += 1;
        
      }
    }
  }
  
  reproduce() {
    
    for (let i = 0; i < this.populationAmt; i++) {
      
      this.popArr[i].mutate();
      
      let par1;
      let par2;
    
      par1 = random(this.matingPool);
      par2 = random(this.matingPool);     
      
      this.popArr[i].fitness = 0;
      
      for (let j = 0; j < this.target.length; j++) {
        if (random(0, 1) < 0.5) {
          this.popArr[i].letters[j] = par1.letters[j];
        
        } else {
          this.popArr[i].letters[j] = par2.letters[j];
        
        }
      }
    }
  }
}