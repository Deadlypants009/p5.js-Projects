class DNA {
  constructor(l) {
    this.length = l;
    this.fitness = 0;
    
    this.alphabet = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '_'];
    
    this.letters = [];
    for (let i = 0; i < this.length; i++) {
      this.letters[i] = this.alphabet[floor(random(26))];
      
    }
  }
  
  mutate() {
    if (floor(random(1, population.mutation * 100)) == 1) {
      this.letters[floor(random(this.letters.length))] = this.alphabet[floor(random(this.alphabet.length))];

    }
  }
}