let population;
let targetPhrase = 'sigma';
let mutation = 0.00001;
let populationSize = 1;
let generations = 0;

function setup() {
  createCanvas(1000, 500);
  population = new Population(targetPhrase, mutation, populationSize);
  
  population.calFitness();
  // population.fillPool();
  // population.reproduce();
  
}

function draw() {
  background(255);
  
  for (let i = 0; i < 10; i++) {
    population.fillPool();
    population.reproduce();
    population.calFitness();
    generations += 1;
  }
  
  textSize(17);
  text('Best Fitness: ' + round(population.maxFitness, 4), 20, 50);
  text('Best: ' + population.bestDNA.letters, 20, 80);
  text('Generation: ' + generations, 20, 110);
  
  for (let i = 0; i < population.popArr.length; i++) {
    text(population.popArr[i].letters, width - 15 * targetPhrase.length, i * 15 + 50);
    
  }
}