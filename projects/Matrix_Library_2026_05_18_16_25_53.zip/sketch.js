let creatures = [];
let food = [];

let numCreatures = 50;

let birthRate = 0.0006;
let mutationRate = 0.05;

function setup() {
  createCanvas(400, 400);
  
  angleMode(DEGREES);
    
  food.push(new Food(width / 2, height / 2));
  
  for (let i = 0; i < numCreatures; i++) {
    creatures[i] = new Creature(random(width), random(height), new DNA(random(0, 1)));
    creatures[i].lifetime = random(1000);
  }
}

function draw() {
  background(255);
  
  for (let i = 0; i < creatures.length; i++) {
    creatures[i].update();
    creatures[i].show();
    if (creatures[i].lifetime < 0) {
      food.push(new Food(creatures[i].pos.x, creatures[i].pos.y));
      creatures.splice(i, 1);
    }
  }
  
  for (let i = 0; i < food.length; i++) {
    food[i].show();
  }
}