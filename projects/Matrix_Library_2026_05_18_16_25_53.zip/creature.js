class Creature {
  constructor(x, y, dna) {
    this.pos = createVector(x, y);
    this.vel = createVector(0, 0);
    this.angle = random(360);
    this.lifetime = 1000;
    this.dna = dna;
    this.radius = map(this.dna.data[0], 0, 1, 10, 80) / 2;
  }
  
  update() {
    this.lifetime--;
    this.reproduce();
    
    if (random(0, 1) < 0.1) {
      this.angle += noise(this.lifetime); 
    }
    if (random(0, 1) < 0.1) {
      this.angle -= noise(this.lifetime);
    }
    
    this.vel = p5.Vector.fromAngle(this.angle, 1);
    
    this.vel.normalize();
    this.vel.setMag(map(this.dna.data[0], 0, 1, 4, 0.5));
    
    this.pos.add(this.vel);
    
    if (this.pos.x < -40) {
      this.pos.x = width + 40;
    }
    if (this.pos.x > width + 40) {
      this.pos.x = -40;
    }
    if (this.pos.y > height + 40) {
      this.pos.y = -40;
    }
    if (this.pos.y < -40) {
      this.pos.y = width + 40;
    }
    
    for (let i = 0; i < food.length; i++) {
      if (this.collides(food[i])) {
        food.splice(i, 1);
        this.lifetime = 1000;
      }
    }
    
  }
  
  show() {
    fill(0, map(this.lifetime, 1000, 0, 255, 0));
    noStroke();
    circle(this.pos.x, this.pos.y, this.radius * 2);
  }
  
  
  
  reproduce() {
    if (random(0, 1) < birthRate) {
      let dna = new DNA(this.dna.data[0]);
      dna.mutate(mutationRate);
      creatures.push(new Creature(this.pos.x, this.pos.y, dna));
    }
  }
  
  
  collides(object) {
    if (dist(this.pos.x, this.pos.y, object.pos.x, object.pos.y) < this.radius) {
      return true;
    }
  }
}