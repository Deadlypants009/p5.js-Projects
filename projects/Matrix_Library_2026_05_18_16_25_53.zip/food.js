class Food {
  constructor(x, y) {
    this.pos = createVector(x, y);
    this.w = 10;
    this.h = 10;
  }
  
  show() {
    rectMode(CENTER);
    fill(99, 53, 0);
    rect(this.pos.x, this.pos.y, this.w, this.h);
  }
}