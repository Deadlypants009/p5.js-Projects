class DNA {
  constructor(data) {
    this.data = [data];
  }
  
  mutate(amount) {
    for (let i = 0; i < this.data.length; i++) {
      if (random(0, 1) < 0.5) {
        this.data[i] -= amount;
      } else {
        this.data[i] += amount;
      }
      if (this.data[i] > 1) {
        this.data[i] = 1;
      }
      if (this.data[i] < 0) {
        this.data[i] = 0;
      }
    }
  }
}