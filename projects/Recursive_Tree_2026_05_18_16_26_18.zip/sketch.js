let angle;

function setup() {
  createCanvas(400, 400);
  
  angleMode(DEGREES);
  
  colorMode(HSB);
  
  translate(width / 2, height);
}

function draw() {
  background(0);
  
  angle = map(mouseX % width, 0, width, 0, 360);
  
  resetMatrix();
  
  translate(width / 2, height);
  
  branch(100, 0);
}



function branch(n, level) {
  
  if (n < 1.5) {
    return;
  }
  
  stroke((level * 30) % 360, 255, 255);
  line(0, 0, 0, -n);
  
  translate(0, -n);
  
  n *= 0.66;
  
  push();
  rotate(angle);
  branch(n, level + 1);
  pop();
  
  push();
  rotate(-angle);
  branch(n, level + 1);
  pop();
  
}