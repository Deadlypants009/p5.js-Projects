class Vehicle {
  
  constructor(x, y) {
    
    this.pos = createVector(x, y);
    this.vel = createVector(0, 0);
    this.acc = createVector(0, 0);
    this.r = 15;
    this.maxSpeed = 7;
    this.maxForce = 0.3;
    this.c = [];
    
  }
  
  edges() {
    
    if (this.pos.x < 0) {
      this.pos.x = width;
    }
    if (this.pos.x > width) {
      this.pos.x = 0;
    }
    if (this.pos.y < 0) {
      this.pos.y = height;
    }
    if (this.pos.y > height) {
      this.pos.y = 0;
    }
  }
  
  applyForce(force) {
    
    this.acc.add(force);
    
  }
  
  touching(vehicle) {
    
    if (dist(this.pos.x, this.pos.y, vehicle.pos.x, vehicle.pos.y) > this.r + vehicle.r) {
      return false;
    } else {
      return true;
    } 
  }
  
  arrive(target) {
    
    let force = p5.Vector.sub(target, this.pos);
    let r = 100;
    let d = force.mag();
    force.setMag(this.maxSpeed);
    if (d < r) {
      
      let m = map(d, 0, r, 0, this.maxSpeed);
      force.setMag(m);
      
    } else {
      
      force.setMag(this.maxSpeed);
      
    }
    
    force.sub(this.vel);
    force.limit(this.maxForce);
    return force;
  }
  
  pursue(vehicle) {
    
    let targetPos = vehicle.pos.copy();
    let targetVel = vehicle.vel.copy();
    targetVel.mult(7);
    targetPos.add(targetVel);
    return this.seek(targetPos);
  }
  
  evade(vehicle) {
    
    let pos = this.pursue(vehicle);
    pos.mult(-1);
    return pos;
  }
  
  flee(target) {
    return this.seek(target).mult(-1);
  }
  
  seek(target) {
    let force = p5.Vector.sub(target, this.pos);
    force.setMag(this.maxSpeed);
    force.sub(this.vel);
    force.limit(this.maxForce);
    return force;
  }
  
  reset() {
    
    this.pos.set(random(width), random(height));
    
  }
  
  update() {
    
    this.edges();
    
    this.vel.add(this.acc);
    this.vel.limit(this.maxSpeed);
    this.pos.add(this.vel);
    
    this.acc.set(0);
    
  }
  
  show() {
    
    stroke(0);
    strokeWeight(1);
    fill(this.c);
    push();
    translate(this.pos.x, this.pos.y);
    rotate(this.vel.heading());
    triangle(-1.5*this.r, this.r, -1.5*this.r, -this.r, 1.5*this.r, 0);
    pop();
    
  }
  
}




class Pursuit {
  
  constructor(x, y) {
    
    this.pos = createVector(x, y);
    this.vel = createVector(random(-6, 6), random(-6, 6));
    this.acc = createVector(0, 0);
    this.r = 15;
    
  }
  
  reset() {
    
    this.pos.set(random(width), random(height));
    this.vel.set(random(-6, 6), random(-6, 6));
    
  }
  
  update() {
    
    this.edges();
    
    this.vel.limit(this.maxSpeed);
    this.vel.add(this.acc);
    this.pos.add(this.vel);
    
    this.acc.set(0);
    
  }
  
  edges() {
    
    if (this.pos.x < 0) {
      this.pos.x = width;
    }
    if (this.pos.x > width) {
      this.pos.x = 0;
    }
    if (this.pos.y < 0) {
      this.pos.y = height;
    }
    if (this.pos.y > height) {
      this.pos.y = 0;
    }
  }
  
  show() {
    
    fill(255);
    circle(this.pos.x, this.pos.y, this.r*2);
    
  }
}