let pursuer;
let target;

function setup() {
  createCanvas(windowWidth, windowHeight);
  
  pursuer = new Vehicle(width / 2, height / 2);
  target = new Vehicle(width / 2, height / 2);
  
  pursuer.c = [255];
  target.c = [0, 255, 0];
  
  pursuer.maxSpeed = 6;
  
}

function draw() {
  background(0);
  
  pursuer.update();
  pursuer.show();
  target.update();
  target.show();
  
  let mouse = createVector(mouseX, mouseY);
  let targetSteering = target.arrive(mouse);
  target.applyForce(targetSteering);
  
  let steering = pursuer.pursue(target);
  pursuer.applyForce(steering);
  
//   if (pursuer.touching(target)) {
    
//     pursuer.reset();
//     target.reset();
//     target.vel.set(random(-5, 5), random(-5, 5));
    
//   }
}


class Target {
  
  constructor(x, y) {
    
    this.pos = createVector(x, y);
    this.c = [];
    
  }
  
  show() {
    
    this.pos.x = mouseX;
    this.pos.y = mouseY;
    
    noStroke();
    fill(this.c);
    circle(this.pos.x, this.pos.y, 30);
    
  }
  
}