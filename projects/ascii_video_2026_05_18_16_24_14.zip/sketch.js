let bright = 'ÑÑÑÑÑ@#W$98765433210?!abc;:+=-,._ ';
let extraBrightness = 40;

let video;

function setup() {
  
  createCanvas(400, 400);
  
  background(0);

  video = createCapture(VIDEO);
  video.size(40, 40);
  
}

function draw() {
  
  background(0);
  
  video.loadPixels();
  
  let w = height / video.width;
  let h = width / video.height;
  
  for (let y = 0; y < video.height; y++) {
    for (let x = 0; x < video.width; x++) {
      
      let i = (x + y * video.width) * 4;
      
      let r = video.pixels[i + 0];
      let g = video.pixels[i + 1];
      let b = video.pixels[i + 2];
      
      let avg = (r + g + b) / 3 + extraBrightness;
      
      let l = floor(map(avg, 0, 255 + extraBrightness, bright.length, 0));
      
      fill(constrain(r + extraBrightness, 0, 255), constrain(g + extraBrightness, 0, 255), constrain(b + extraBrightness, 0, 255));
      text(bright.charAt(l), x * (w + 0.5), y * (h + 0.5));
      
    }
  } 
}