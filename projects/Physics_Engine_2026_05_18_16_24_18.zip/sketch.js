let balls = [];

let gravity;
let wind;
let friction = 0.05;
let drag = 0.1;
let density = 0.0025;

function setup() {
  createCanvas(400, 400);
  gravity = createVector(0, 0.2);
  wind = createVector(0.2, 0);
  
}

function keyPressed() {
  if (keyCode == 32) {
    balls.push(new Ball(mouseX, mouseY, random(1, 4))); 
  }
}

function draw() {
  background(255);
  
  if (mouseIsPressed) {
    //wind
    for (let i = 0; i < balls.length; i++) {
      balls[i].applyForce(wind);
    }
  }

  
  for (let i = 0; i < balls.length; i++) {
    //gravity
    balls[i].applyForce(p5.Vector.mult(gravity, balls[i].m));
    balls[i].edge();
    balls[i].update();
    balls[i].show();
  }
  
}