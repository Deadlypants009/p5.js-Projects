class Ball {
  
  constructor(x, y, m) {
    this.m = m;
    this.r = Math.sqrt(this.m * 200);
    this.acc = createVector(0, 0);
    this.vel = createVector(0, 0);
    this.force = createVector(0, 0);
    this.pos = createVector(x, y);  
  }
  
  update() {
    
    this.drag();
    this.acc.add(this.force);
    this.vel.add(this.acc);
    this.pos.add(this.vel);
    
    this.force.set(0, 0);
    this.acc.set(0, 0);
    
  }
  
  applyForce(force) {
    this.acc.add(p5.Vector.div(force, this.m));
  }
  
  friction() {
    
    let f = this.vel.copy();
    f.mult(-1);
    f.normalize();
    f.setMag(friction);
    
    this.applyForce(f);
  }
  
  drag() {
    
    let area = (2 * PI * this.r) / 2;
    
    let d = this.vel.copy();
    d.mult(-1);
    d.normalize();
    
    let v = this.vel.magSq();
    
    d.setMag(v * (1/2) * area * drag * density);
    
    this.applyForce(d);
    
  }
  
  edge() {
    if (this.pos.y > height - this.r) {
      this.pos.y = height - this.r;
      this.vel.y *= -1;
      this.friction();
    }
    if (this.pos.y < this.r) {
      this.pos.y = this.r;
      this.vel.y *= -1;
    }
    if (this.pos.x > width - this.r) {
      this.pos.x = width - this.r;
      this.vel.x *= -1;
    }
     if (this.pos.x < this.r) {
      this.pos.x = this.r;
      this.vel.x *= -1;
    }
  }
  
  
  show() {
    
    strokeWeight(2);
    stroke(0);
    noFill();
    ellipse(this.pos.x, this.pos.y, this.r * 2);
    stroke(0, 255, 0);
    line(this.pos.x, this.pos.y, this.pos.x + (this.vel.x * 8), this.pos.y + (this.vel.y * 8));
    
  }
  
}