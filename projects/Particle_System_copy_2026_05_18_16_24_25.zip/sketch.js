let risingForce;
let emitters  = [];
let img;
let wind;
let r = 200;
let g = 40;
let b = 15;

function preload() {
  img = loadImage('texturedCircle.png');
}

function setup() {
  blendMode(ADD);
  createCanvas(400, 400);
  
  risingForce = createVector(0, -0.05);

}

function draw() {
  clear();
  background(0);
  blendMode(ADD);
  
  // let dir = map(mouseX, 0, width, -0.1, 0.1);
  // wind = createVector(dir, 0);
  
  for (let emitter of emitters) {
    
    emitter.update();
    
  }
  
}

function mousePressed() {
  
  emitters.push(new Emitter(mouseX, mouseY));
  
}