class Emitter {
  
  constructor(x, y) {
    
    this.pos = createVector(x, y);
    this.particles = [];
    
  }
  
  update() {
    
    for (let i = 0; i < this.particles.length; i++) {
      
      this.particles[i].update();
      this.particles[i].show();
      
    }
    
    this.addParticle();
    this.checkDead();
    
    
  }
  
  addParticle() {
    
    for (let i = 0; i < 3; i++) {
      this.particles.push(new Particle(this.pos.x, this.pos.y, random(-1.2, 1.2), random(-1.2, 1.2), r, g, b));
    }
  }
  
  checkDead() {
    
    for (let i = 0; i < this.particles.length; i++) {
      
      if (this.particles[i].lifeSpan <= 0) {
        
        this.particles.splice(i, 1);
        
      }
    }
  }
  
}