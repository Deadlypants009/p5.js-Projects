class Particle {
  
  constructor(x, y, xa, ya, r, g, b) {
    
    this.pos = createVector(x, y);
    this.vel = createVector();
    this.acc = createVector(xa, ya);
    this.lifeSpan = 255;
    this.r = 12;
    this.c = [r, g, b];
    
  }
  
  update() {
    
    this.lifeSpan -= 3;
    
    this.applyForce(risingForce);
    this.applyForce(wind);
    
    this.vel.add(this.acc);
    this.pos.add(this.vel);
    
    this.acc.set(0);
  }
  
  applyForce(force) {
    
    this.acc.add(force);
    
  }
  
  show() {
    
    tint(this.c[0], this.c[1], this.c[2], this.lifeSpan);
    imageMode(CENTER);
    image(img, this.pos.x, this.pos.y, this.r*2, this.r*2);
    
    
//     noStroke();
//     fill(this.c[0], this.c[1], this.c[2], this.lifeSpan);
//     circle(this.pos.x, this.pos.y, this.r * 2);
    
  }
}