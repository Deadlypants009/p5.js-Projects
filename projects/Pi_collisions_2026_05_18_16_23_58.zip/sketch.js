let block1;
let block2;
let num = 0;
let itterations = 500000;
let exponent = 7;
let weight;

class Block{
  constructor(m, v, x, c, s) {
    this.m = m;
    this.v = v;
    this.x = x;
    this.c = c;
    this.s = s;
    
  }
  
  show() {
    fill(this.c, 0, 0);
    rect(this.x, height / 2 - this.s, this.s);
    fill(255);
    // circle(this.x + (this.s / 3), width / 2 - this.s + this.s / 4, this.s / 4);
    // circle(this.x + 2 * (this.s / 3), width / 2 - this.s + this.s / 4, this.s / 4);
  }
  
  move() {
    this.x += this.v / itterations;
    if (this.x <= 0) {
      this.v *= -1;
      num += 1;
      pulse.start();
      
    }
  }
  
  collide(object) {  
    
    if (object.x + object.s >= this.x) {
      let Om = object.m;
      let Ov = object.v;
      let originalV = this.v;
      let newV = ((this.m - Om) * originalV + (2 * Om * Ov)) / (this.m + Om);
      let oNewV = ((Om - this.m) * Ov + (2 * this.m * originalV)) / (this.m + Om);
    
      this.v = newV;
    
      object.v = oNewV;
      
      num += 1;
      pulse.start();
    }  
  } 
}

function setup() {
  weight = pow(100, exponent);
    
  createCanvas(400, 400);
  block1 = new Block(weight, -1, width / 2 + 100, 255, 100);
  block2 = new Block(1, 0, width / 2 - 100, 104, 40);
  
  pulse = new p5.Pulse();
  pulse.amp(0.1);
  pulse.freq(220);
  
  // saveGif('pi', 9.011);
}

function draw() {
  background(0);
  fill(255);
  rect(0, height / 2, width, height);
  
  
  block1.show();
  block2.show();
  for (let i = 0; i < itterations; i++) {
   block1.move();
   block2.move();
   block1.collide(block2);
  }
  pulse.stop();
  fill(0);
  textSize(40);
  text(num, 10, height / 4 * 3)
  
}