let spheres = [];

let angle = 0;

let numRingsSlider;

let c = 0;

function setup() {
  createCanvas(400, 400, WEBGL);
  
  colorMode(HSB);
  
  numRingsSlider = createSlider(1, 10, 1, 1);
      
  angleMode(DEGREES);
}

function draw() {
  
  background(0);
  
  orbitControl();
  
  angle++;
  c++;
  if (c > 360) {
    c = 0;
  }
  
  if (frameCount % 10 == 0) {
    for (let i = 0; i < numRingsSlider.value(); i++) {
      spheres.push(new Sph(sin(angle % 360 + 360 / numRingsSlider.value() * i) * 100, 0, cos(angle % 360 + 360 / numRingsSlider.value() * i) * 100));
    }
  }
  
  for (let i = 0; i < spheres.length; i++) {
    spheres[i].show();
    spheres[i].pos.y -= 1;
    
    if (spheres[i].lifeTime <= 0) {
      spheres.splice(i, 1);
    }
  }
}


class Sph {
  constructor(x, y, z) {
    this.pos = createVector(x, y, z);
    this.lifeSpan = 1000;
    this.lifeTime = this.lifeSpan;
  }
  
  show() {
    push();
    translate(this.pos);
    fill(c, 100, 100);
    stroke(c, 100, 100);
    sphere(8, 6, 4);
    pop();
    this.lifeTime--;
  }
}