let population;
let targetPhrase = 'bob';
let mutation = 0.001;
let populationSize = 1;
let generations = 0;

function setup() {
  createCanvas(800, 800);
  population = new Population(targetPhrase, mutation, populationSize);
  
  population.calFitness();
  // population.fillPool();
  // population.reproduce();
  
}

function draw() {
  background(255);
  
  for (let i = 0; i < 10; i++) {
    population.fillPool();
    population.reproduce();
    population.calFitness();
    generations += 1;
  }
  
  textSize(17);
  text('Best Fitness: ' + round(population.maxFitness, 4), 20, 50);
  text('Best: ' + population.bestDNA.letters, 20, 80);
  text('Generation: ' + generations, 20, 110);
  
  for (let i = 0; i < population.popArr.length; i++) {
    text(population.popArr[i].letters, width - 15 * targetPhrase.length, i * 15 + 50);
    
  }
}