let tileImages = [];
let tileImagePaths = [
  "/Tiles/Empty.png",           // 0
  "/Tiles/North-T.png",         // 1
  "/Tiles/East-T.png",          // 2
  "/Tiles/South-T.png",         // 3
  "/Tiles/West-T.png",          // 4
  "/Tiles/Horizontal-Line.png", // 5
  "/Tiles/Vertical-Line.png",   // 6
  "/Tiles/Top-Right.png",       // 7
  "/Tiles/Bottom-Right.png",    // 8
  "/Tiles/Bottom-Left.png",     // 9
  "/Tiles/Top-Left.png",        // 10
  "/Tiles/Cross.png"            // 11
];

let rules = [
  // north, east, south, west
  [0, 0, 0, 0], // 0
  [1, 1, 0, 1], // 1
  [1, 1, 1, 0], // 2
  [0, 1, 1, 1], // 3
  [1, 0, 1, 1], // 4
  [0, 1, 0, 1], // 5
  [1, 0, 1, 0], // 6
  [1, 1, 0, 0], // 7
  [0, 1, 1, 0], // 8
  [0, 0, 1, 1], // 9
  [1, 0, 0, 1], // 10
  [1, 1, 1, 1]  // 11
];

const Tiles = {
  EMPTY : 0,
  NORTH_T : 1,
  EAST_T : 2,
  SOUTH_T : 3,
  WEST_T : 4,
  HORIZONTAL_LINE : 5,
  VERTICLE_LINE : 6,
  TOP_RIGHT : 7,
  BOTTOM_RIGHT : 8,
  BOTTOM_LEFT : 9,
  TOP_LEFT : 10,
  CROS : 11
}

let grid;

let availableTiles;

let collapsedTiles;

let tileSize = 8;

let cols, rows;
  
function preload() {
  for (let i = 0; i < tileImagePaths.length; i++) {
    tileImages[i] = loadImage(tileImagePaths[i]);
  }
}


function setup() {
  createCanvas(400, 400);
  
  randomSeed();
  
  cols = width / tileSize;
  rows = height / tileSize;
  
  grid = create2DArray(rows, cols);
  availableTiles = create2DArray(rows, cols);
  collapsedTiles = create2DArray(rows, cols);
  
  for (let i = 0; i < grid.length; i++) {
    for (let j = 0; j < grid[i].length; j++) {
      grid[i][j] = Tiles.EMPTY;
    }
  }
  
  for (let i = 0; i < grid.length; i++) {
    for (let j = 0; j < grid[i].length; j++) {
      collapsedTiles[i][j] = 0;
    }
  }
  
  for (let i = 0; i < availableTiles.length; i++) {
    for (let j = 0; j < availableTiles[i].length; j++) {
      availableTiles[i][j] = [
        Tiles.EMPTY,
        Tiles.NORTH_T,
        Tiles.EAST_T,
        Tiles.SOUTH_T,
        Tiles.WEST_T,
        Tiles.HORIZONTAL_LINE,
        Tiles.VERTICLE_LINE,
        Tiles.TOP_RIGHT,
        Tiles.BOTTOM_RIGHT,
        Tiles.BOTTOM_LEFT,
        Tiles.TOP_LEFT,
        Tiles.CROS
      ];
    }
  }
  
  collapseTile(floor(cols / 2), floor(rows / 2));
  
}

function draw() {
  background(255);
  
  drawGrid();
  
  let lowestAvailable = rules.length + 1;
  let lowestAvailablePos = createVector(0, 0);
  
  for (let i = 0; i < availableTiles.length; i++) {
    for (let j = 0; j < availableTiles[i].length; j++) {
      if (collapsedTiles[i][j] != 1) {
        if (availableTiles[i][j].length < lowestAvailable) {
          lowestAvailable = availableTiles[i][j].length;
          lowestAvailablePos = createVector(i, j);
        }
      }
    }
  }
  
  collapseTile(lowestAvailablePos.x, lowestAvailablePos.y);
  
  let allCollapsed = true;
  
  for (let i = 0; i < collapsedTiles.length; i++) {
    for (let j = 0; j < collapsedTiles[i].length; j++) {
      if (collapsedTiles[i][j] == 0) {
        allCollapsed = false;
      }
    }
  }
  
  if (allCollapsed) {
    drawGrid();
    console.log("finished");
    noLoop();
  }
  
}


function drawGrid() {
  for (let i = 0; i < grid.length; i++) {
    for (let j = 0; j < grid[i].length; j++) {
      
      if (collapsedTiles[i][j] == 1) {
        image(tileImages[grid[i][j]], i * tileSize, j * tileSize, tileSize, tileSize);
      } else {
        let opacity = map(availableTiles[i][j].length, 0, 11, 0, 200);
        fill(0, 0, 255, opacity);
        noStroke();
        rect(i * tileSize, j * tileSize, tileSize, tileSize);
      }
//       noFill();
//       stroke(0);
//       rect(i * tileSize, j * tileSize, tileSize, tileSize);
      
    }
  }
}


function collapseTile(i, j) {
  if (availableTiles[i][j].length > 0) {
    grid[i][j] = random(availableTiles[i][j]);
    collapsedTiles[i][j] = 1;
    updateAvailable(i, j);
  } else {
    console.log("Stuck");
  }
}

function updateAvailable(i, j) {
  let state = grid[i][j];
  let r = rules[state];
  
  let n = r[0];
  let e = r[1];
  let s = r[2];
  let w = r[3];
  
  if (j > 0) {
    for (let k = 0; k < rules.length; k++) {
      if (rules[k][2] != n) {
        arrayRemove(availableTiles[i][j-1], k);
      }
    }
  }
  
  if (i <= cols - 2) {
    for (let k = 0; k < rules.length; k++) {
      if (rules[k][3] != e) {
        arrayRemove(availableTiles[i+1][j], k);
      }
    }
  }
  
  if (j <= rows - 2) {
    for (let k = 0; k < rules.length; k++) {
      if (rules[k][0] != s) {
        arrayRemove(availableTiles[i][j+1], k);
      }
    }
  }
  
  if (i > 0) {
    for (let k = 0; k < rules.length; k++) {
      if (rules[k][1] != w) {
        arrayRemove(availableTiles[i-1][j], k);
      }
    }
  }
  
}





