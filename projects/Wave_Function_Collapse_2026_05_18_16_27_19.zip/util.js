function create2DArray(rows, cols) {
  let arr = new Array(cols);
  for (let i = 0; i < cols; i++) {
    arr[i] = new Array(cols);
  }
  return arr;
}


function search2DArray(arr, value) {
  for (let i = 0; i < arr.length; i++) {
    for (let j = 0; j < arr[i].length; j++) {
      if (arr[i][j] == value) {
        return true;
      }
    }
  }
  return false;
}


function search3DArray(arr, value) {
  for (let i = 0; i < arr.length; i++) {
    for (let j = 0; j < arr[i].length; j++) {
      for (let k = 0; k < arr[i][j].length; k++) {
        if (arr[i][j][k] == value) {
          return true;
        }
      }
    }
  }
  return false;
}



function arrayRemove(arr, value) {
  if (arr) {
    for (let i = 0; i < arr.length; i++) {
      if (arr[i] == value) {
        arr.splice(i, 1);
      }
    }
  }
}