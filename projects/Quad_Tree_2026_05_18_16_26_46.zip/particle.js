class Particle {
  constructor(x, y) {
    
    this.position = createVector(x, y);
    
    this.colliding = false;
    
    this.radius = particleRadius;
    
    this.data = random(100);
    
  }
  
  show() {
    noStroke();
    fill(0, 255, 0);
    if (this.colliding) {
      fill(255, 0, 0);
    }
    circle(this.position.x, this.position.y, this.radius * 2);
  }
}