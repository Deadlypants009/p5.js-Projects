let particleAmount = 100;

let maxPoints = 4;

let particleRadius = 8;

let quadTree;

let a;

function setup() {
  createCanvas(400, 400);
  
  a = new Particle(1, 1);
  
  quadTree = new Quad(0, 0, width);
  
  for (let i = 0; i < particleAmount; i++) {
    let x = random(width);
    let y = random(height);
    
    let p = new Particle(x, y);
    p.velocity = p5.Vector.random2D();
    
    quadTree.insert(p);
  }
  
  quadTree.insert(a);
  
  let x = quadTree.search(a);
  
}

function draw() {
  background(0);
  
  quadTree.show();
  
  quadTree.collide();
  
  let particles = quadTree.getAll();
  
  for (let p of particles) {
    p.show();
  }
  
}

function mouseDragged() {
  let p = new Particle(mouseX, mouseY);
  quadTree.insert(p);
}


function inRect(px, py, rx, ry, rw, rh) {
  
  return px < rx + rw && px > rx && py < ry + rh && py > ry
  
}