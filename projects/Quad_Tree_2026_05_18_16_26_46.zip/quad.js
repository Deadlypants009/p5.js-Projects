class Quad {
  
  constructor(x, y, w) {
    
    this.position = createVector(x, y);
    
    this.w = w;
    
    this.topLeft = null;
    this.topRight = null;
    this.botLeft = null;
    this.botRight = null;
    
    this.points = [];
    
  }
  
  show() {
    noFill();
    stroke(0, 0, 255);
    strokeWeight(1);
    rect(this.position.x, this.position.y, this.w, this.w);
    
    if (this.topLeft) {
      this.topLeft.show();
      this.topRight.show();
      this.botLeft.show();
      this.botRight.show();
    }
  }
  
  getAll() {
    let a = [];
    
    if (this.topLeft) {
      a = concat(a, this.topLeft.getAll());
      a = concat(a, this.topRight.getAll());
      a = concat(a, this.botLeft.getAll());
      a = concat(a, this.botRight.getAll());
    } else {
      for (let p of this.points) {
        if (p) {
          a.push(p);
        }
      }
    }
    
    return a;
  }
  
  
  collide() {
    if (this.topLeft) {
      this.topLeft.collide();
      this.topRight.collide();
      this.botLeft.collide();
      this.botRight.collide();
    } else {
      
      for (let i = 0; i < this.points.length; i++) {
        for (let j = 0; j < this.points.length; j++) {
          if (this.points[i] && this.points[j]) {
            if (i != j) {
              if (p5.Vector.dist(this.points[i].position, this.points[j].position) <= particleRadius * 2) {
                this.points[i].colliding = true;
                this.points[j].colliding = true;
              } else {
                this.points[i].colliding = false;
                this.points[j].colliding = false;
              }
            }
          }
        }
      }
      
    }
  }
  
  
  insert(p) {
    
    if (!inRect(p.position.x, p.position.y, this.position.x, this.position.y, this.w, this.w)) {
      return;
    }
    
    if (this.points.length < maxPoints) {
        this.points.push(p);

        return;
    } else if (!this.topLeft) {
      
      this.topLeft = new Quad(this.position.x, this.position.y, this.w / 2);
      this.topRight = new Quad(this.position.x + this.w / 2, this.position.y, this.w / 2);
      this.botLeft = new Quad(this.position.x, this.position.y + this.w / 2, this.w / 2);
      this.botRight = new Quad(this.position.x + this.w / 2, this.position.y + this.w / 2, this.w / 2);
      
      for (let p of this.points) {
        this.topLeft.insert(p);
        this.topRight.insert(p);
        this.botLeft.insert(p);
        this.botRight.insert(p);
      }
      
      this.points = new Array(maxPoints + 1);
      
    }
    
    this.topLeft.insert(p);
    this.topRight.insert(p);
    this.botLeft.insert(p);
    this.botRight.insert(p);
    
  }
  
  
  search(p) {
    
    if (this.topLeft) {
      
      let w = this.topLeft.search(p);
      let x = this.topRight.search(p);
      let y = this.botLeft.search(p);
      let z = this.botRight.search(p);
      if (w) {
        return w;
      }
      if (x) {
        return x;
      }
      if (y) {
        return y;
      }
      if (z) {
        return z;
      }
      
    } else {
      
      for (let b of this.points) {
        if (b.data == p.data) {
          return b;
        }
      }
      
    }
    
    
  }
  
  
}