let d = 0.1;
let zoff = 0;

let resolutionDist = 5;

let resolution;

let zoom;
let unZoom;

function setup() {
  createCanvas(400, 400);
  
  zoom = createButton('zoom');
  unZoom = createButton('unZoom');
  
  resolution = createSlider(1, 10, 5, 1);
  
  colorMode(HSB);
}

function draw() {
  background(255);
  
  resolutionDist = map(resolution.value(), 1, 10, 10, 1);
  
  zoom.mousePressed(() => {
    d /= 2;
  });
  unZoom.mousePressed(() => {
    d *= 2;
  });
  
  zoff += 0.1 / 5;
  let xoff = 0;
  
  for (let x = 0; x < width; x += resolutionDist) {
    
    xoff += d;
    let yoff = 0;
    
    for (let y = 0; y < height; y += resolutionDist) {
      yoff += d;
      
      let v = map(noise(xoff, yoff, zoff), 0, 1, 0, 360);
      fill(v, 100, 100);
      noStroke();
      square(x, y, resolutionDist);
    }
  }
}