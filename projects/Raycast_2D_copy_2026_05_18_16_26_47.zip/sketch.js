let walls = [];

let rays = [];

let groundColor = [100];
let ceilingColor = [0];

let playerPos;
let playerDir;

let rayMaxLength = 576;

let playerTurnSpeed = 0.05;
let playerSpeed = 1;
let playerSize = 12;

// if number of rays is not a multiple of the width
// there will be slight artifacting between slices
let playerFOV = 80;
let rayInterval = 1;

let sliceWidth;

function setup() {
  createCanvas(800, 400);
  
  playerFOV = radians(playerFOV);
  rayInterval = radians(rayInterval);
  
  playerPos = createVector(width / 4, height / 2);
  playerDir = 0;
  
  addRays();
  
  sliceWidth = width / 2 / rays.length;
  
  walls.push(new Wall(100, 100, 200, 100, [255, 0, 0]));
  walls.push(new Wall(200, 100, 275, 175, [100, 0, 0]));
  
  walls.push(new Wall(0, 0, 0, height, [0, 255, 255])); // left
  walls.push(new Wall(0, 0, width / 2, 0, [0, 255, 0])); // top
  walls.push(new Wall(width / 2, 0, width / 2, height, [0, 0, 255])); // right
  walls.push(new Wall(0, height, width / 2, height, [255, 0, 255])); // bottom
}

function draw() {
  fill(0);
  noStroke();
  rect(0, 0, width / 2, height);
  fill(0);
  rect(width / 2, 0, width / 2, height);
  
  for (let wall of walls) {
    wall.show();
  }
  
  for (let ray of rays) {
    ray.collide();
    ray.show();
  }
  
  updateRays();
  
  drawPlayer();
  
  if (keyIsDown(RIGHT_ARROW)) {
    playerDir += playerTurnSpeed;
  }
  if (keyIsDown(LEFT_ARROW)) {
    playerDir -= playerTurnSpeed;
  }
  if (keyIsDown(UP_ARROW)) {
    playerPos.add(p5.Vector.fromAngle(playerDir + PI / 2).setMag(playerSpeed));
  }
  if (keyIsDown(DOWN_ARROW)) {
    playerPos.sub(p5.Vector.fromAngle(playerDir + PI / 2).setMag(playerSpeed));
  }
  
  
  for (let i = 0; i < rays.length; i++) {
    
    let h = map(rays[i].l, 0, rayMaxLength, height / 2, 0);
    
    /* adjusts the heights of the
    slices so that they match the 
    x resolution of the slices */
    // h = h - (h % sliceWidth);
    
    let xPos = i * sliceWidth + width / 2;
    let yPos = (height / 2) - h / 2;
    
    noStroke();
    fill(rays[i].collidingColor);
    rect(xPos, yPos, sliceWidth, h);
    fill(groundColor);
    rect(xPos, yPos + h, sliceWidth, height - (yPos + h));
    fill(ceilingColor);
    rect(xPos, 0, sliceWidth, yPos);
    
  }
  
  
}

function addRays() {
  
  for (let i = -playerFOV / 2; i < playerFOV / 2; i += rayInterval) {
    
    rays.push(new Ray(playerPos.x, playerPos.y, i + PI / 2));
    
  }
  
}

function updateRays() {
  
  for (let ray of rays) {
    
    ray.x1 = playerPos.x;
    ray.y1 = playerPos.y;
    
    ray.dir = ray.originalDir + playerDir;
    
  }
  
}


function drawPlayer() {
  
  push();
  translate(playerPos);
  rotate(playerDir);
  fill(255);
  noStroke();
  triangle(-playerSize, -playerSize, playerSize, -playerSize, 0, playerSize);
  pop();
  
}




function lineIntersection(x1, y1, x2, y2, x3, y3, x4, y4) {

    // Check if none of the lines are of length 0
    if ((x1 === x2 && y1 === y2) || (x3 === x4 && y3 === y4)) {
        return false;
    }

    const denominator = ((y4 - y3) * (x2 - x1) - (x4 - x3) * (y2 - y1));

    // Lines are parallel
    if (denominator === 0) {
        return false;
    }

    let ua = ((x4 - x3) * (y1 - y3) - (y4 - y3) * (x1 - x3)) / denominator;
    let ub = ((x2 - x1) * (y1 - y3) - (y2 - y1) * (x1 - x3)) / denominator;

    // is the intersection along the segments
    if (ua < 0 || ua > 1 || ub < 0 || ub > 1) {
        return false;
    }

    // Return a object with the x and y coordinates of the intersection
    let x = x1 + ua * (x2 - x1);
    let y = y1 + ua * (y2 - y1);

    return { x, y }
}