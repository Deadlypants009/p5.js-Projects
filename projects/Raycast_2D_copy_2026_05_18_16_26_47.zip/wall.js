class Wall {
  constructor(x1, y1, x2, y2, c) {
    
    this.x1 = x1;
    this.y1 = y1;
    this.x2 = x2;
    this.y2 = y2;
    
    this.c = c;
    
  }
  
  show() {
    stroke(this.c);
    strokeWeight(8);
    line(this.x1, this.y1, this.x2, this.y2);
  }
}