class Ray {
  constructor(x1, y1, dir) {
    this.x1 = x1;
    this.y1 = y1;
    this.originalDir = dir;
    this.dir = dir + playerDir;
    
    this.collidingColor = [0];
    
    this.maxLength = rayMaxLength;
    
    this.l = this.maxLength;
    
  }
  
  collide() {
    
    this.l = this.maxLength;
    this.c = [50];
    
    for (let wall of walls) { 
      
      let x2 = playerPos.x + cos(this.dir) * this.l;
      let y2 = playerPos.y + sin(this.dir) * this.l;
      
      let intersection = lineIntersection(this.x1, this.y1, x2, y2, wall.x1, wall.y1, wall.x2, wall.y2);
      
      if (intersection) {
        
        // fill(255, 0, 0);
        // circle(intersection.x, intersection.y, 8);
        
        this.l = dist(this.x1, this.y1, intersection.x, intersection.y);
        
        this.collidingColor = wall.c;
        
      }
      
    }
  }
  
  
  show() {
    
    strokeWeight(1);
    stroke(255);
    let x2 = playerPos.x + cos(this.dir) * this.l;
    let y2 = playerPos.y + sin(this.dir) * this.l;
    line(this.x1, this.y1, x2, y2);
    
  }
  
}