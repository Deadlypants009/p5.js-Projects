let maxDepthSlider;
let maxDepth = 3;

function setup() {
  createCanvas(400, 400);
  
  maxDepthSlider = createSlider(-1, 5, maxDepth, 1);
  
  background(255);
  
  carpet(width, 0);
}


function draw() {
  background(255);
  
  maxDepth = maxDepthSlider.value();
  
  carpet(width, 0);
}




function carpet(n, level) {
  
  if (level > maxDepth) {
    return;
  }
  
  level++;
  
  fill(0);
  noStroke();
  square(n / 3, n / 3, n / 3);
  
  n = n / 3;
  
  for (let i = 0; i < 3; i++) {
    for (let j = 0; j < 3; j++) {
      if (!(i == 1 && j == 1)) {
        push();
        translate(i * n, j * n);
        carpet(n, level);
        pop();
      }
    }
  }
}