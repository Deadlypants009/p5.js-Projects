function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(0);
  
  drawClock(width / 2, height / 2, 300);
}



function drawClock(x, y, s) {
  angleMode(DEGREES);
  
  translate(x, y);
  rotate(-90);
  
  let hr = hour();
  let mn = minute();
  let sc = second();
  
  let size = s;
  
  let scRad = size - (size * 4 / 29);
  let mnRad = size - (size * 2 / 29);
  let hrRad = size;
  
  noFill();
  strokeWeight(size / 29);
  
  stroke(0, 0, 255);
  arc(0, 0, hrRad, hrRad, 0, map(hr % 12, 0, 12, 0, 360));
  push();
  rotate(map(hr % 12, 0, 12, 0, 360));
  line(0, 0, size / 4.64, 0);
  pop();
  
  stroke(0, 255, 0);
  arc(0, 0, mnRad, mnRad, 0, map(mn, 0, 60, 0, 360));
  push();
  rotate(map(mn, 0, 60, 0, 360));
  line(0, 0, size / 2.9, 0);
  pop();
  
  stroke(255, 0, 0);
  arc(0, 0, scRad, scRad, 0, map(sc, 0, 60, 0, 360));
  push();
  rotate(map(sc, 0, 60, 0, 360));
  line(0, 0, size / 2.9, 0);
  pop();
  
  stroke(255);
  point(0, 0);
}