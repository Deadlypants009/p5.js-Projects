class ConvexPolygon {
  
  constructor(pointArr, c = [0, 200, 255]) {
    
    this.vertices = pointArr;
    this.c = c;
    
  }
  
  
  show() {
    fill(this.c);
    stroke(0);
    strokeWeight(2);
    
    beginShape();
    for (let i = 0; i < this.vertices.length; i++) {
      vertex(this.vertices[i].x, this.vertices[i].y);
    }
    endShape(CLOSE);
  }
  
  move(v) {
    for (let i = 0; i < this.vertices.length; i++) {
      this.vertices[i].add(v);
    }
  }
  
  project(vector) {
    let minimum = Infinity;
    let maximum = -Infinity;
        
    for (let i = 0; i < this.vertices.length; i++) {
      let dotProduct = p5.Vector.dot(this.vertices[i], vector);
      
      minimum = min(minimum, dotProduct);
      maximum = max(maximum, dotProduct);
    }
    
    return { minimum, maximum };
  }
  
  getAxes() {
    let vectors = [];
    
    for (let i = 0; i < this.vertices.length - 1; i++) {
      vectors.push(p5.Vector.sub(this.vertices[i+1], this.vertices[i]));
    }
    vectors.push(p5.Vector.sub(this.vertices[this.vertices.length-1],this.vertices[0]));
    
    for (let vector of vectors) {
      vector.rotate(PI / 2);
      vector.normalize();
    }
    
    return vectors;
  }
  
  getCenter() {
    let center = createVector(0, 0);
    for (let i = 0; i < this.vertices.length; i++) {
      center.add(this.vertices[i]);
    }
    return center.div(this.vertices.length);
  }
  
  
  static checkCollision(poly1, poly2) {
    
    let allAxes = Util.combineArrays(poly1.getAxes(), poly2.getAxes());
    
    let minOverlap = Infinity;
    let minNormal = createVector(0, 0);
    
    for (let i = 0; i < allAxes.length; i++) {
      let p1Results = poly1.project(allAxes[i]);
      let p2Results = poly2.project(allAxes[i]);
      
      if (p1Results.maximum < p2Results.minimum || p2Results.maximum < p1Results.minimum) {
        return new CollisionInformation(
          false, // collides
          poly1, // object1
          poly2, // object2
          null, // normal direction
          null // penetration depth
        );
      } else {
        let overlap = min(p1Results.maximum - p2Results.minimum, p2Results.maximum - p1Results.minimum);

        if (overlap < minOverlap) {
          minOverlap = overlap;
          minNormal = allAxes[i].copy();
          let direction = p5.Vector.sub(
            poly2.getCenter(),
            poly1.getCenter()
          );

          if (p5.Vector.dot(direction, minNormal) > 0) {
            minNormal.mult(-1);
          }
          
        }
      }
    }
    
    return new CollisionInformation(
      true, // collides
      poly1, // object1
      poly2, // object2
      minNormal, // normal direction
      minOverlap // penetration depth      
    );
  }
  
  
  
}