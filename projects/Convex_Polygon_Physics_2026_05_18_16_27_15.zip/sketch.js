let polygons = [];

function setup() {
  createCanvas(400, 400);
  
  polygons.push(
    new ConvexPolygon([
      createVector(width / 2 - 20, height / 2 - 0 ),
      createVector(width / 2 + 20, height / 2 - 10),
      createVector(width / 2 + 60, height / 2 + 20),
      createVector(width / 2 + 40, height / 2 + 60),
      createVector(width / 2 + 0 , height / 2 + 40)
    ])
  );
  
  polygons.push(
    new ConvexPolygon([
      createVector(width - 40 , height / 2 - 0 ),
      createVector(width - 80 , height / 2 - 10),
      createVector(width - 120, height / 2 + 20),
      createVector(width - 100, height / 2 + 60)
    ])
  );
  
}

function draw() {
  background(255);
  
  for (let poly of polygons) {
    poly.show();
    for (let other of polygons) {
      if (poly != other) {
        if (ConvexPolygon.checkCollision(poly, other).collides) {
          poly.c = [255, 0, 0];
        } else {
          poly.c = [0, 100, 255];
        }
      }
    }
  }
  
  polygons[1].move(createVector(-1, 0));
  
  if (polygons[1].getCenter().x < -50) {
    polygons[1].move(createVector(width + 50, 0));
  }
  
}