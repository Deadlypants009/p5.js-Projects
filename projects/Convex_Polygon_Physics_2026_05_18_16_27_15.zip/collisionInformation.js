class CollisionInformation {
  
  constructor(collides, object1, object2, normalDirection, penetrationDepth) {
    this.collides = collides;
    this.object1 = object1;
    this.object2 = object2;
    this.normalDirection = normalDirection;
    this.penetrationDepth = penetrationDepth;
  }
  
}