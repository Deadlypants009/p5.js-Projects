class Util {
  
  static combineArrays(arr1, arr2) {
    let output = [];
    for (let i = 0; i < arr1.length; i++) {
      output.push(arr1[i]);
    }
    for (let i = 0; i < arr2.length; i++) {
      output.push(arr2[i]);
    }
    return output;
  }
  
  
  // let axis = polygons[0].getAxes()[0];
  static showDotProducts(axis) {
    let p1Results = polygons[0].project(axis);
    let p2Results = polygons[1].project(axis);

    line(0, height / 2, width, height / 2);

    let minimum = min(p1Results.minimum, p2Results.minimum);
    let maximum = max(p1Results.maximum, p2Results.maximum);

    fill(255, 0, 0);
    circle(map(p1Results.minimum, minimum, maximum, 0, width), height / 2, 10);
    circle(map(p1Results.maximum, minimum, maximum, 0, width), height / 2, 10);
    fill(0, 255, 0);
    circle(map(p2Results.minimum, minimum, maximum, 0, width), height / 2, 10);
    circle(map(p2Results.maximum, minimum, maximum, 0, width), height / 2, 10);
  }
  
  static vectorLine(v1, v2) {
    line(v1.x, v1.y, v2.x, v2.y);
  }
  
}