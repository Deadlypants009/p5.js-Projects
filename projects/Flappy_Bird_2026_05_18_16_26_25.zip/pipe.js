class Pipe {
  constructor(x, y, h) {
    this.pos = createVector(x, y);
    this.h = h;
    this.w = 50;
  }
  
  update() {
    this.pos.x -= speed;
    
  }
  
  show() {
    fill(50, 255, 100);
    rect(this.pos.x, this.pos.y, this.w, this.h);
  }
}