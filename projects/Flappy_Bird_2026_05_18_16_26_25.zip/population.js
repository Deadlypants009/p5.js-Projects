class Population {
  constructor(populationSize) {
    
    this.populationSize = populationSize;
    
    this.matingPool = [];
    
    this.population = [];
    
    for (let i = 0; i < this.populationSize; i++) {
      this.population[i] = new Bird(75, height / 2);
    }
  }
  
  fillMatingPool() {
    this.matingPool = [];
    for (let i = 0; i < this.populationSize; i++) {
      let bird = this.population[i];      
      for (let j = 0; j < bird.fitness; j++) {
        this.matingPool.push(bird);
      }
    }
  }
  
  reproduce() {
    let newPopulation = [];
    
    let bestFitness = 0;
    let bestBird;
    
    for (let i = 0; i < this.populationSize; i++) {
      if (this.population[i].fitness > bestFitness) {
        bestBird = this.population[i];
        bestFitness = this.population[i].fitness;
      }
    }
    
    if (bestFitness == 0) {
      bestBird = random(this.matingPool);
    }
    
    bestBird.pos.x = 75;
    bestBird.pos.y = height / 2;
    bestBird.fitness = 0;
    bestBird.dead = false;
    newPopulation.push(bestBird);
    
    for (let i = 0; i < this.populationSize - 1; i++) {
      let parentA = random(this.matingPool);
      let parentB = random(this.matingPool);
      
      let child = crossOver(parentA, parentB);
      
      newPopulation.push(child);
    }
    
    this.population = newPopulation;
    offScreen();
  }
  
}


function crossOver(parentA, parentB) {
  
  let child = new Bird(75, height / 2);
  
  let parentAInputWeights = parentA.nn.weights_ih.data;
  let parentBInputWeights = parentB.nn.weights_ih.data;
  
  for (let i = 0; i < parentA.nn.weights_ih.rows; i++) {
    child.nn.weights_ih.data[i] = combineHalfArray(parentAInputWeights[i], parentBInputWeights[i]);
    mutate(child.nn.weights_ih.data[i], mutationRate, learningRate);
  }
  
  let parentAHiddenWeights = parentA.nn.weights_ho.data;
  let parentBHiddenWeights = parentB.nn.weights_ho.data;
  
  for (let i = 0; i < parentA.nn.weights_ho.rows; i++) {
    child.nn.weights_ho.data[i] = combineHalfArray(parentAHiddenWeights[i], parentBHiddenWeights[i]);
    mutate(child.nn.weights_ho.data[i], mutationRate, learningRate);
  }
  
  let parentAHiddenBias = parentA.nn.bias_h;
  let parentBHiddenBias = parentB.nn.bias_h;
  
  let childBias_hArray = combineHalfArray(toArray(parentAHiddenBias), toArray(parentBHiddenBias));
  mutate(childBias_hArray, mutationRate, learningRate);
  child.nn.bias_h = fromArray(childBias_hArray);
  
  let parentAOutputBias = parentA.nn.bias_o;
  let parentBOutputBias = parentB.nn.bias_o;
  
  let childBias_oArray = combineHalfArray(toArray(parentAOutputBias), toArray(parentBOutputBias));
  mutate(childBias_oArray, mutationRate, learningRate);
  child.nn.bias_o = fromArray(combineHalfArray(toArray(parentAOutputBias), toArray(parentBOutputBias)));
  
  return child;
}


function mutate(array, mutationRate, learningRate) {
  for (let i = 0; i < array.length; i++) {
    if (random(mutationRate) < 1) {
      if (random(1) < 0.5) {
        array[i] += learningRate;
      } else {
        array[i] -= learningRate;
      }
    }
  }
}


function combineHalfArray(arrayA, arrayB) {
  let a = Array.from(arrayA);
  let aLength = a.length;
  let b = Array.from(arrayB);
  let middle = floor(a.length / 2)
  let halfA = a.splice(0, middle);
  let halfB = b.splice(floor(a.length / 2), ceil(b.length / 2));
  return halfA.concat(halfB);
}




