// !* This is an older project and must use p5.js version 1.0.0 *!

// space to pause and play
// L to load population.json file (somewhat trained ai) !Replaces Current Generation!
// D to enable downloading after every 100 generations or when new all time best reached (Only turn on after a few generations so that you don't download for every new frame the birds get to, alternativly change the allTimeBest variable manually in the console)
// S to download current generation
// B to see the amount of non-dead birds

// fitness counted in frames of life
// pipes come every 200 frames

let birds;

let topPipe;
let bottomPipe;

let gravity;

let mutationRate = 0.5;
let learningRate = 0.0001;

let populationSize = 400;

let speed = 2; // trained on a speed of 2

let generation = 0;

let allTimeBest = 0;

let running = true;

let downloading = false;

let jsonPath = "population.json";

let bestFitness = 0;

function preload() {
  json = loadJSON(jsonPath);
}

function setup() {
  createCanvas(400, 400);
  
  gravity = createVector(0, 0.5);
  
  bottomPipe = new Pipe(width, 200, 200);
  topPipe = new Pipe(width, 0, 50);
  
  birds = new Population(populationSize);
  
  birds.fillMatingPool(); 
}

function draw() {
  if (running) {
        
    if (generation % 100 == 0 && generation != 0 && downloading && bestFitness == 0) {
      getPopulation(bestFitness, generation);
    }
    
    background(50, 120, 250);
    
    topPipe.update();
    topPipe.show();
    bottomPipe.update();
    bottomPipe.show();
    bestFitness = 0;

    for (let i = 0; i < birds.populationSize; i++) {
      birds.population[i].update();
      birds.population[i].show();
      birds.population[i].updateInputs();

      if (birds.population[i].fitness > bestFitness) {
        bestFitness = birds.population[i].fitness;
      }

      if (birds.population[i].nn.feedForward(birds.population[i].inputs) > 0.75) {
        birds.population[i].jump();
      }
      if (isColliding(birds.population[i], topPipe) || isColliding(birds.population[i], bottomPipe)) {
        if (!birds.population[i].dead) {
          birds.population[i].dead = true;
        }
      }
      if (birds.population[i].pos.y <= 0 || birds.population[i].pos.y >= height - birds.population[i].h) {
        if (!birds.population[i].dead) {
          birds.population[i].dead = true;
        }
      }
    }

    if (topPipe.pos.x < -topPipe.w) {
      offScreen();
    }

    let dead = 0;

    for (let i = 0; i < populationSize; i++) {
      if (birds.population[i].dead) {
        dead++;
      }
    }

    if (dead == populationSize) {
      if (bestFitness > allTimeBest) {
        allTimeBest = bestFitness;
        if (downloading) {
          getPopulation(allTimeBest, generation);
        }
      }
      birds.fillMatingPool();
      birds.reproduce();
      generation++;
      print("Generation: " + generation + ", Best Fitness: " + bestFitness + ", All Time Best: " + allTimeBest);
    }
    drawNN(width - 125, 0, 150, 100, 8, 7, 20, 1);
  }
}


function getPopulation(fitness, generation) {
  let data = [];
  for (let bird of birds.population) {
    data.push(bird);
  }
  saveJSON(data, fitness.toString() + "_" + generation.toString());
}


function loadPopulation(file) {
  let bestFitness = 0;
  for (let i = 0; i < populationSize; i++) {
    let birdnn = birds.population[i].nn;
    birdnn.weights_ih.data = file[i].nn.weights_ih.data;
    birdnn.weights_ho.data = file[i].nn.weights_ho.data;
    birdnn.bias_h.data = file[i].nn.bias_h.data;
    birdnn.bias_o.data = file[i].nn.bias_o.data;
    if (file[i].fitness > bestFitness) {
      bestFitness = file[i].fitness;
    }
  }
  if (allTimeBest < bestFitness) {
    allTimeBest = bestFitness;
  }
  console.log("data loaded");
}


function run(speed) {
  if (running) {
    for (let z = 0; z < speed; z++) {
      topPipe.update();
      bottomPipe.update();

      let bestFitness = 0;

      for (let i = 0; i < birds.populationSize; i++) {
        birds.population[i].update();
        birds.population[i].updateInputs();

        if (birds.population[i].fitness > bestFitness) {
          bestFitness = birds.population[i].fitness;
        }

        if (birds.population[i].nn.feedForward(birds.population[i].inputs) > 0.75) {
          birds.population[i].jump();
        }
        if (isColliding(birds.population[i], topPipe) || isColliding(birds.population[i], bottomPipe)) {
          if (!birds.population[i].dead) {
            birds.population[i].dead = true;
          }
        }
        if (birds.population[i].pos.y <= 0 || birds.population[i].pos.y >= height - birds.population[i].h) {
          if (!birds.population[i].dead) {
            birds.population[i].dead = true;
          }
        }
      }

      if (topPipe.pos.x < -topPipe.w) {
        offScreen();
      }

      let dead = 0;

      for (let i = 0; i < populationSize; i++) {
        if (birds.population[i].dead) {
          dead++;
        }
      }

      if (dead == populationSize) {
        if (bestFitness > allTimeBest) {
          allTimeBest = bestFitness;
          if (downloading) {
            getPopulation(allTimeBest, generation);
          }
        }
        birds.fillMatingPool();
        birds.reproduce();
        generation++;
        print("Generation: " + generation + ", Best Fitness: " + bestFitness + ", All Time Best: " + allTimeBest);
      }
    }
  }
}


function drawNN(x, y, w, h, d, numInputs, numHidden, numOutputs) {
  fill(0);
  
  translate(x, y);
  
  let inputHeight = h / numInputs;
  for (let i = 0; i < numInputs; i++) {
    let x = w / 4;
    let y = inputHeight * i + inputHeight / 2;
    fill(255);
    circle(x, y, d);
    let hiddenHeight = h / numHidden;
    for (let j = 0; j < numHidden; j++) {
      line(x, y, w / 2, hiddenHeight * j + hiddenHeight / 2);
    }
  }
  let hiddenHeight = h / numHidden;
  for (let i = 0; i < numHidden; i++) {
    let x = w / 2;
    let y = hiddenHeight * i + hiddenHeight / 2;
    fill(255);
    circle(x, y, d);
    let outputHeight = h / numOutputs;
    for (let i = 0; i < numOutputs; i++) {
      line(x, y, 3 * w / 4, outputHeight * i + outputHeight / 2);
    }
  }
  let outputHeight = h / numOutputs;
  for (let i = 0; i < numOutputs; i++) {
    fill(255);
    circle(3 * w / 4, outputHeight * i + outputHeight / 2, d);
  }
}


function offScreen() {
  let r = random(75, height - 75 - 150);
  topPipe = new Pipe(width, 0, r);
  bottomPipe = new Pipe(width, r + 150, height - r + 150);
}


function isColliding(a, b) {
  let x1 = a.pos.x;
  let y1 = a.pos.y;
  let w1 = a.w;
  let h1 = a.h;
  
  let x2 = b.pos.x;
  let y2 = b.pos.y;
  let w2 = b.w;
  let h2 = b.h;
  
  if (x1 < x2 + w2 &&
      x1 + w1 > x2 &&
      y1 < y2 + h2 &&
      y1 + h1 > y2) {
    return true;
  } else {
    return false;
  }
}



function getBestBird() {
  let bestBird = null;
  let bestFitness = 0;
  for (let i = 0; i < populationSize; i++) {
    if (birds.population[i].fitness > bestFitness) {
      bestBird = birds.population[i];
      bestFitness = birds.population[i].fitness;
    }
  }
  return bestBird;
}



function keyPressed() {
  // space key
  if (keyCode == 32) {
    running = !running;
    if (running) {
      console.log("running");
    } else {
      console.log("paused");
    }
  }
  // s key
  if (keyCode == 83) {
    getPopulation(bestFitness, generation);
    console.log("getting population")
  }
  // l key
  if (keyCode == 76) {
    loadPopulation(json);
  }
  // d key
  if (keyCode == 68) {
    downloading = !downloading;
    if (downloading) {
      console.log("downloading enabled");
    } else {
      console.log("downloading disabled");
    }
  }
  // b key
  if (keyCode == 66) {
    console.log("Birds left: " + countBirds());
  }
}


function countBirds() {
  let count = 0;
  for (let bird of birds.population) {
    if (!bird.dead) {
      count++;
    }
  }
  return count;
}



