class Bird {
  constructor(x, y) {
    this.pos = createVector(x, y);
    this.vel = createVector(0, 0);
    this.acc = createVector(0, 0);
    this.jumpForce = createVector(0, -25);
    this.w = 25;
    this.h = 25;
    this.maxSpeed = 5;
    
    this.dead = false;
    
    this.fitness = 0;
    this.nn = new NeuralNetwork(7, 20, 1);
    this.inputs = [];
    this.updateInputs();
  }
  
  updateInputs() {
    this.inputs = [map(this.pos.y, 0, height, -1, 1), 
                   this.vel.y / 2, 
                   this.acc.y / 2, 
                   map(topPipe.pos.x, 0, width, -1, 1), 
                   map(topPipe.pos.y, 0, height, -1, 1), 
                   map(bottomPipe.pos.x, 0, width, -1, 1), 
                   map(bottomPipe.pos.y, 0, height, -1, 1)];
  }
  
  update() {
    
    this.updateInputs();
    
    if (!this.dead) {
      this.fitness++;
    }
    
    this.applyForce(gravity);
    this.vel.add(this.acc);
    
    this.vel.limit(10);
    
    this.pos.add(this.vel);
    
    if (this.pos.y > height - this.h) {
      this.pos.y = height - this.h;
    }
    if (this.pos.y < 0) {
      this.pos.y = 0;
    }
    
    this.acc.set(0);
  }
  
  applyForce(force) {
    this.acc.add(force);
  }
  
  show() {
    if (!this.dead) {
      fill(255, 255, 0);
      rect(this.pos.x, this.pos.y, this.w, this.h);
    }
  }
  
  jump() {
    this.applyForce(this.jumpForce);
  }
}