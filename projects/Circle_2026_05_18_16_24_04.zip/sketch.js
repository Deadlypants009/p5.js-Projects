let radius = 200;
let aStepSize;
let numVert = 1;

function setup() {
  createCanvas(windowWidth, windowHeight); 
  // saveGif('circle', 11.485);
}

function draw() {
  background(0);
  
  let radius = height / 2;
  
  numVert += 0.02;
  
  if (numVert > 15) {
    numVert = 1;
    console.log(millis());
  }
  
  aStepSize = PI / (numVert / 2);
  
  translate(width / 2, height / 2);
  
  stroke(255);
  
  noFill();
  
  beginShape();
  
  for (let angle = 0; angle < TWO_PI; angle += aStepSize) {
    
    let x = cos(angle) * radius / 2;
    let y = sin(angle) * radius / 2;
  
    vertex(x, y);
  
  }
  
  endShape(CLOSE);
  
}