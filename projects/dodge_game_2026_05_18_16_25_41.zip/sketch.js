let mouse;

let bullets = [];

let bulletMaxSpeed = 4;
let bulletMaxForce = 0.1;

let dead = false;
let score = 0;

let spawnSpeed = 100;

function setup() {
  createCanvas(400, 400);
  
  mouse = new Mouse(mouseX, mouseY, 8);
  
  bullets.push(new Bullet(width * 2, height * 2, 18));
  bullets.push(new Bullet(-width * 2, -height * 2, 12));
}

function draw() {
  background(0);
  
  textSize(32);
  fill(255);
  textAlign(CENTER);
  text(score, width / 2, 50);
  
  if (frameCount % spawnSpeed == 0) {
    let r = floor(random(4));
    if (r == 0) {
      bullets.push(new Bullet(-40, random(height), random(12, 18)));
    }
    if (r == 1) {
      bullets.push(new Bullet(width + 40, random(height), random(12, 18)));
    }
    if (r == 2) {
      bullets.push(new Bullet(random(width), -40, random(12, 18)));
    }
    if (r == 3) {
      bullets.push(new Bullet(random(width), height + 40, random(12, 18)));
    }
  }
  
  mouse.update();
  mouse.show();
  
  for (let i = 0; i < bullets.length; i++) {
    if (bullets[i].dead == false) {
      bullets[i].update();
      bullets[i].show();
    
      if (collides(bullets[i], mouse)) {
        dead = true;
      }
    }
  }
  
  for (let i = 0; i < bullets.length; i++) {
    for (let j = 0; j < bullets.length; j++) {
      if (i != j) {
        if (collides(bullets[i], bullets[j])) {
          bullets[i].dead = true;
          bullets[j].dead = true;
        }
      }
    }
  }
  
  
  if (dead) {
    bullets = [];
    
    background(255, 0, 0);
    textSize(32);
    fill(0);
    textAlign(CENTER);
    text(score, width / 2, height / 2);
    text('click to play again', width / 2, height / 2 + 50);
  }
  
  
  for (let i = bullets.length - 1; i >= 0; i--) {
    if (bullets[i].dead == true) {
      bullets.splice(i, 1);
      score += 0.5;
    }
  }
}

function mousePressed() { 
  if (dead) {
    reset();
  }
}


function reset() {
  
  dead = false;
  score = 0;
  bullets = [];
  
}

function collides(object1, object2) {
  let d = dist(object1.pos.x, object1.pos.y, object2.pos.x, object2.pos.y);
  
  let r = object1.radius + object2.radius;
  
  if (d < r) {
    return true;
  } else {
    return false;
  }
}


class Bullet {
  
  constructor(x, y, r) {
    
    this.pos = createVector(x, y);
    this.vel = createVector();
    this.acc = createVector();
    this.radius = r;
    this.dead = false;
    
  }
  
  applyForce(force) {
    this.acc.add(force);
  }
  
  update() {
    
    this.applyForce(this.seek(mouse));
    
    this.vel.add(this.acc);
    this.pos.add(this.vel);
    
    this.acc.set(0);
    
  }
  
  show() {
    
    fill(255);
    noStroke();
    circle(this.pos.x, this.pos.y, this.radius * 2);
    
  }
  
  seek(target) {
    let force = p5.Vector.sub(target.pos, this.pos);
    force.setMag(bulletMaxSpeed);
    force.sub(this.vel);
    force.limit(bulletMaxForce);
    return force;
  }
  
}


class Mouse {
  constructor(x, y, r) {
    
    this.pos = createVector(x, y);
    this.radius = r;
    
  }
  
  update() {
    
    this.pos.x = mouseX;
    this.pos.y = mouseY;
    
  }
  
  show() {
    
    fill(255);
    noStroke();
    circle(this.pos.x, this.pos.y, this.radius * 2);
    
  }
}