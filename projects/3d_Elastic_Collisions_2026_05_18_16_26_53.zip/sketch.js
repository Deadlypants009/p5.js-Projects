let particles = [];

let gravity = 0.1;

let elasticity = 0.98;

let windForce = 0.25;

let particleAmount = 200;

let boundry;

let imgTexture;

function preload() {
  imgTexture = loadImage('/lebron.png');
}

function setup() {
  createCanvas(windowWidth, windowHeight, WEBGL);
  
  colorMode(HSB);
  
  boundry = new Boundry(0, 0, 0, 300, 300, 300);
  
  for (let i = 0; i < particleAmount; i++) {
    particles.push(new Particle(random(-boundry.w, boundry.w), random(-boundry.h, boundry.h), random(-boundry.d, boundry.d), 12, random(360)));
  }
  
  for (let particle of particles) {
    particle.applyForce(p5.Vector.random3D().setMag(3));
  }
  
  camera(800, 0, 0, boundry.position.x, boundry.position.y, boundry.position.y, 0, 1, 0);
  
}

function draw() {
  background(0);
  
  orbitControl();
  
  boundry.show();
  
  
  for (let i = 0; i < particles.length; i++) {
    for (let j = 0; j < particles.length; j++) {
      if (i == j) { continue }
        particles[i].collide(particles[j]);
      }
      
      particles[i].applyForce(createVector(0, gravity, 0));
      particles[i].update();
      particles[i].edges();
      particles[i].show();
      
      if (keyIsDown(39)) {
        particles[i].applyForce(createVector(windForce, 0));
      }
      if (keyIsDown(37)) {
        particles[i].applyForce(createVector(-windForce, 0));
      }
      if (keyIsDown(38)) {
        particles[i].applyForce(createVector(0, -windForce));
      }
      if (keyIsDown(40)) {
        particles[i].applyForce(createVector(0, windForce));
      }
  }
}



