class Particle {
  
  constructor(x, y, z, r, c) {
    this.position = createVector(x, y, z);
    this.velocity = createVector(0, 0, 0);
    this.acceleration = createVector(0, 0, 0);
    
    this.xRotation = random(360);
    this.yRotation = random(360);
    this.zRotation = random(360);
    
    this.radius = r;
    this.col = c;
  }
  
  update() {
    this.velocity.add(this.acceleration);
    this.position.add(this.velocity);
    
    this.acceleration.set(0);
  }
  
  applyForce(force) {
    this.acceleration.add(force);
  }
  
  edges() {
    if (this.position.x >= boundry.position.x + boundry.w / 2 - this.radius) {
      this.position.x = boundry.position.x + boundry.w / 2 - this.radius;
      this.velocity.x *= -1;
      this.velocity.mult(elasticity);
    }
    if (this.position.x <= boundry.position.x - boundry.w / 2 + this.radius) {
      this.position.x = boundry.position.x - boundry.w / 2 + this.radius;
      this.velocity.x *= -1;
      this.velocity.mult(elasticity);
    }
    if (this.position.y >= boundry.position.y + boundry.h / 2 - this.radius) {
      this.position.y = boundry.position.y + boundry.h / 2 - this.radius;
      this.velocity.y *= -1;
      this.velocity.mult(elasticity);
    }
    if (this.position.y <= boundry.position.y - boundry.h / 2 + this.radius) {
      this.position.y = boundry.position.y - boundry.h / 2 + this.radius;
      this.velocity.y *= -1;
      this.velocity.mult(elasticity);
    }
    if (this.position.z >= boundry.position.z + boundry.d / 2 - this.radius) {
      this.position.z = boundry.position.z + boundry.d / 2 - this.radius;
      this.velocity.z *= -1;
      this.velocity.mult(elasticity);
    }
    if (this.position.z <= boundry.position.z - boundry.d / 2 + this.radius) {
      this.position.z = boundry.position.z - boundry.d / 2 + this.radius;
      this.velocity.z *= -1;
      this.velocity.mult(elasticity);
    }
  }
  
  collide(other) {
    if (p5.Vector.dist(this.position, other.position) < this.radius + other.radius) {
      
      let sumRadius = this.radius + other.radius;
      
      let dir = p5.Vector.sub(other.position, this.position);
      let dst = dir.mag();
      
      let cDst = sumRadius - dst;
      
      this.position.sub(dir.copy().setMag(cDst / 2));
      other.position.add(dir.copy().setMag(cDst / 2));
      
      let t = other.velocity.copy();
      other.velocity = this.velocity;
      this.velocity = t;
      this.velocity.mult(elasticity);
      other.velocity.mult(elasticity);
    }
  }
  
  show() {
    push();
    translate(this.position);
    fill(this.col, 100, 100);
    // stroke(0);
    noStroke();
    // texture(imgTexture);
    rotateX(this.xRotation);
    rotateY(this.yRotation);
    rotateZ(this.zRotation);
    sphere(this.radius, 10, 10);
    pop();
  }
  
}