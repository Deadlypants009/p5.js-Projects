class Boundry {
  constructor(x, y, z, w, h, d) {
    
    this.position = createVector(x, y, z);
    
    this.w = w;
    this.h = h;
    this.d = d;
    
  }
  
  show() {
    push();
    translate(this.position);
    stroke(255);
    strokeWeight(2);
    noFill();
    box(this.w, this.h, this.d);
    pop();
  }
}