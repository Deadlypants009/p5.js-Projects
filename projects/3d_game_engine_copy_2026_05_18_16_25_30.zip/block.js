class Block {
  constructor(isAlive, size, x, y, z) {
    
    this.pos = createVector(x, y, z);
    this.size = size;
    this.isAlive = isAlive;
    this.ang = createVector(0, 0, 0);
    
  }
  
  show() {
    if (this.isAlive) {
      push();
      
      stroke((generation * 2) % 360, 100, 100);
      
      translate(this.pos);
      rotateX(this.ang.x);
      rotateY(this.ang.y);
      rotateZ(this.ang.z);
      box(this.size);
      pop();
    }
  }
}