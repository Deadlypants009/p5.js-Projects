let currentGen;
let cam;

let running = true;

let generation = 0;

let speed;
let speedSlider;

let pauseButton;

let rows = 16;
let cols = 16;
let depth = 16;
let w = 20;


function setup() {
  createCanvas(windowWidth, windowHeight - 50, WEBGL);
  
  pauseButton = createButton('Pause');
  pauseButton.position(150, height + 15);
  
  createDiv('Speed').style('color', 'black').style('backgroundColor', 'white').style('width', '40px');
  speedSlider = createSlider(1, 20, 15);
  
  cam = createCamera();
  
  cam.camera(144, -407, 879, 145, 168, 112, 0, 1, 0);
        
  currentGen = create3DArray(rows, cols, depth);
  
  for (let i = 0; i < rows; i++) {
    for (let j = 0; j < cols; j++) {
      for (let k = 0; k < depth; k++) {
        currentGen[i][j][k] = new Block(false, w, i * w, j * w, k * w);
        if (random(1) < 0.1) {
          currentGen[i][j][k].isAlive = true;
        }
      }
    }
  }
  
    
  fill(255);
  strokeWeight(2);
}

function draw() {
  background(0);
  
  speed = round(map(speedSlider.value(), 1, 20, 60, 1));
  
  colorMode(HSB);
  
  frameRate(60);
  
  orbitControl();
    
  for (let i = 0; i < currentGen.length; i ++) {
    for (let j = 0; j < currentGen[0].length; j++) {
      for (let k = 0; k < currentGen[0][0].length; k++) {
        currentGen[i][j][k].show();
      }
    }
  }
  
  pauseButton.mousePressed(() => {
    running = !running;
  });
  
  if (frameCount % speed == 0 && running) {
    updateGrid();
  }
  
}


function updateGrid() {
  
  let nextGen = create3DArray(rows, cols, depth);
  
  for (let i = 0; i < rows; i++) {
    for (let j = 0; j < cols; j++) {
      for (let k = 0; k < depth; k++) {
        nextGen[i][j][k] = new Block(false, w, i * w, j * w, k * w);
      }
    }
  }
  
  for (let i = 1; i < currentGen.length - 1; i ++) {
    for (let j = 1; j < currentGen[0].length - 1; j++) {
      for (let k = 1; k < currentGen[0][0].length - 1; k++) {
        
        //survives
        if (currentGen[i][j][k].isAlive) {
          if (neighbors(i, j, k) == 5 || neighbors(i, j, k) == 6) {
            nextGen[i][j][j].isAlive = true;
          }
        }
        //birth
        if (neighbors(i, j, k) == 4 && currentGen[i][j][k].isAlive == false) {
          nextGen[i][j][k].isAlive = true;
        }
        
      }
    }
  }
  
  currentGen = nextGen;
  generation++;
  
}


function neighbors(x, y, z) {
  
  let n = 0;
  
  for (let dx = -1; dx <= 1; dx++) {
    for (let dy = -1; dy <= 1; dy++) {
      for (let dz = -1; dz <= 1; dz++) {
        if (currentGen[x + dx][y + dy][z + dz].isAlive) {
          if (dx == 0 && dy == 0 && dz == 0) {
            //do nothing
          } else {
            n += 1;
          }
        }
      }
    }
  }
  return n;
}


function create3DArray(rows, cols, depth) {
  let arr = [];
  for (let i = 0; i < rows; i++) {
    arr[i] = [];
    for (let j = 0; j < cols; j++) {
      arr[i][j] = [];
      for (let k = 0; k < depth; k++) {
        arr[i][j][k] = '';
      }
    }
  }
  return arr;
}


