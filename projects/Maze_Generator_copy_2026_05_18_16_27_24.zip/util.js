function create2DArray(cols, rows) {
  let arr = new Array(cols);
  for (let i = 0; i < cols; i++) {
    arr[i] = new Array(rows);
  }
  return arr;
}

function fill2DArray(arr, value) {
  for (let i = 0; i < arr.length; i++) {
    for (let j = 0; j < arr[i].length; j++) {
      arr[i][j] = value;
    }
  }
}


function random2dArray(arr) {
  let x = floor(random(arr.length));
  let y = floor(random(arr[x].length));
  return arr[x][y];
}