let w;
let grid = [];
let numTiles = 261; // number of tiles left to right, resolution of image, has to be odd
let currentGen = [];
let nextGen;
let gen = 0;
let rule = 86; // 0-255, rules for next generation
let binary;

function setup() {
  createCanvas(windowWidth, windowHeight);
  
  colorMode(HSB);
  
  binary = decimalToBinary(rule);
  
  for (let i = 0; i < (numTiles / 2) - 1; i++) {
    currentGen.push(0);
  }
  currentGen.push(1);
  for (let i = 0; i < (numTiles / 2) - 1; i++) {
    currentGen.push(0);
  }
  
  w = width / numTiles;

  background(255);
}

function draw() {
    
  grid.push(currentGen);
  nextGen = evolve(currentGen);
  currentGen = nextGen;
  gen++;
  
  noStroke();
  
  for (let i = 0; i < currentGen.length; i++) {
    if (currentGen[i] == 1) {
      fill((gen * 5)%360, 255, 255);
      // fill(0);
    } else {
      fill(255);
    }
    rect(i*w, gen*w, w, w);
  }
  
  // for (let i = 0; i < grid.length; i++) {
  //   for (let j = 0; j < grid[i].length; j++) {
  //     if (grid[i][j] == 1) {
  //       fill((i * 5)%360, 255, 255); //color
  //       // fill(0, 0, 0); //black
  //     } else {
  //       fill(255);
  //     }
  //     noStroke();
  //     rect(j*w, i*w, w, w);
  //   }
  // }
  
  
}

function evolve(arr) {
  
  let newArr = [];
  
  for (let i = 1; i < arr.length - 1; i++) {
    if (arr[i-1] == 1 && arr[i] == 1 && arr[i+1] == 1) {
      newArr[i] = binary.charAt(binary.length-8);
    }
    if (arr[i-1] == 1 && arr[i] == 1 && arr[i+1] == 0) {
      newArr[i] = binary.charAt(binary.length-7);
    }
    if (arr[i-1] == 1 && arr[i] == 0 && arr[i+1] == 1) {
      newArr[i] = binary.charAt(binary.length-6);
    }
    if (arr[i-1] == 1 && arr[i] == 0 && arr[i+1] == 0) {
      newArr[i] = binary.charAt(binary.length-5);
    }
    if (arr[i-1] == 0 && arr[i] == 1 && arr[i+1] == 1) {
      newArr[i] = binary.charAt(binary.length-4);
    }
    if (arr[i-1] == 0 && arr[i] == 1 && arr[i+1] == 0) {
      newArr[i] = binary.charAt(binary.length-3);
    }
    if (arr[i-1] == 0 && arr[i] == 0 && arr[i+1] == 1) {
      newArr[i] = binary.charAt(binary.length-2);
    }
    if (arr[i-1] == 0 && arr[i] == 0 && arr[i+1] == 0) {
      newArr[i] = binary.charAt(binary.length-1);
    }
  }
  
  newArr[0] = 0;
  newArr[arr.length - 1] = 0;
  
  return newArr;
}


function decimalToBinary(N) { 
  let binary = ''; 
  
  while (N > 0) { 
    binary = (N % 2) + binary; 
    N = Math.floor(N / 2); 
  } 
  
  return binary; 
} 