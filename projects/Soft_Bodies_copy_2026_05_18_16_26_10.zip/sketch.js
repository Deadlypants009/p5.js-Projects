// if the simulation is not running you can build
// press 'p' to switch between spring and particle building
// press 'space' to enable and disable the simulation
// while the simulation is running you can click the mouse to add a force to all particles going towards your mouse

let particles = [];
let springs = [];

let gravity = 1;
let elasticity = 0;

let stiffnessSlider;
let stiffness = 0.8;
let dampingSlider;
let damping = 0.2;

let restLengthSlider;
let restLength = 50;

let stiffnessDiv, dampingDiv, restLengthDiv;

let running = false;

let mouseForce = 3;
let mouseDown = false;

let firstSpring = null;

let placingMode = "particle";

function setup() {
  createCanvas(windowWidth, windowHeight - 130);
  
  stiffnessDiv = createDiv("Stiffness");
  stiffnessDiv.style('background-color', 'white');
  stiffnessDiv.size(80);
  stiffnessSlider = createSlider(0, 1, stiffness, 0.1);
  dampingDiv = createDiv("Damping");
  dampingDiv.style('background-color', 'white');
  dampingDiv.size(80);
  dampingSlider = createSlider(0, 1, damping, 0.1);
  restLengthDiv = createDiv("Rest Length");
  restLengthDiv.style('background-color', 'white');
  restLengthDiv.size(80);
  restLengthSlider = createSlider(10, 300, restLength, 10);
}

function draw() {
  background(0);
  
  updateSliders();
  
  stroke(255);
  strokeWeight(1);
  fill(255);
  textSize(10);
  text(placingMode, 10, 20);
  text(running, 10, 35);
  
  if (running) {
    
    if (mouseDown) {
      let mouseVector = createVector(mouseX, mouseY);
      for (let particle of particles) {
        let force = p5.Vector.sub(particle.position, mouseVector);
        force.setMag(mouseForce);
        force.mult(-1);
        particle.applyForce(force);
      }
    }
    
    for (let spring of springs) {
      spring.update();
    }
    
    for (let particle of particles) {
      particle.applyForce(createVector(0, gravity));
      particle.edges();
      particle.update();
    }
  }
  
  
  for (let spring of springs) {
    spring.show();
  }
  for (let particle of particles) {
    particle.show();
  }
  
}


function updateSliders() {
  restLength = restLengthSlider.value();
  damping = dampingSlider.value();
  stiffness = stiffnessSlider.value();
}


function mousePressed() {
  let mouseVector = createVector(mouseX, mouseY);
  if (mouseX > 0 && mouseX < width && mouseY > 0 && mouseY < height) {
    if (running) {
      mouseDown = true;
    } else {
      if (placingMode == "particle") {
        particles.push(new Particle(mouseX, mouseY, 5, 10));
      } else if (placingMode == "spring") {
        let closest = null;
        let closestDist = 999999;
        for (let particle of particles) {
          let d = p5.Vector.sub(particle.position, mouseVector);
          if (d.mag() < closestDist) {
            closestDist = d.mag();
            closest = particle;
          }
        }
        if (firstSpring == null) {
          firstSpring = closest;
        } else {
          springs.push(new Spring(firstSpring, closest, restLength, stiffness, damping));
          firstSpring = null;
        }
      }
    }
  }
}

function mouseReleased() {
  if (running) {
    mouseDown = false;
  }
}


function keyPressed() {
  if (keyCode == 32) {
    running = !running;
  }
  
  if (keyCode == 80) {
    if (placingMode == "particle") {
      placingMode = "spring";
    } else if (placingMode == "spring") {
      placingMode = "particle";
    }
  }
  
}