class Particle {
  
  constructor(x, y, mass, r) {
    this.position = createVector(x, y);
    this.velocity = createVector(0, 0);
    this.acceleration = createVector(0, 0);
    this.mass = mass;
    this.r = r;
  }
  
  applyForce(force) {
    let f = force.copy();
    f.div(this.mass);
    this.acceleration.add(f);
  }
  
  update() {
    this.velocity.add(this.acceleration);
    this.position.add(this.velocity);
    this.acceleration.set(0);
  }
  
  edges() {
    if (this.position.x > width - this.r) {
      this.position.x = width - this.r;
      this.velocity.x *= -elasticity;
    } else if (this.position.x < this.r) {
      this.position.x = this.r;
      this.velocity.x *= -elasticity;
    }

    if (this.position.y > height - this.r) {
      this.position.y = height - this.r;
      this.velocity.y *= -elasticity;
    } else if (this.position.y < this.r) {
      this.position.y = this.r;
      this.velocity.y *= -elasticity;
    }
  }
  
  show() {
    noStroke();
    fill(255);
    circle(this.position.x, this.position.y, this.r * 2);
  }
  
}