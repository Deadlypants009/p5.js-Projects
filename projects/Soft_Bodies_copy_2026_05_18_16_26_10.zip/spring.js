class Spring {
  
  constructor(particleA, particleB, restLength, stiffness, damping) {
    this.restLength = restLength;
    this.stiffness = stiffness;
    this.damping = damping;
    
    this.particleA = particleA;
    this.particleB = particleB;
  }
  
  
  update() {
    let d = p5.Vector.sub(this.particleA.position, this.particleB.position);
    
    let length = d.mag();
    
    let x = length - this.restLength;
    
    let f = d.copy();
    f.setMag(this.stiffness * x);
    
    this.particleB.applyForce(f);
    this.particleA.applyForce(p5.Vector.mult(f, -1));
    
    let dampingForce = p5.Vector.mult(p5.Vector.sub(this.particleA.velocity, this.particleB.velocity), this.damping);
    this.particleA.applyForce(p5.Vector.mult(dampingForce,-1));
    this.particleB.applyForce(dampingForce);
  }
  
  show() {
    stroke(255);
    strokeWeight(2);
    line(this.particleA.position.x, this.particleA.position.y, this.particleB.position.x, this.particleB.position.y);
  }
}