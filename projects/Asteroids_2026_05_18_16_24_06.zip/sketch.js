let player;
let thrust = 0.15;
let resistance = 1;
let bulletSpeed = 5;
let score = 0;
let lives = 1;

let bullets = [];
let astroids = [];

function setup() {
  createCanvas(windowWidth, windowHeight);
  
  player = new Player(width / 2, height / 2, 0, 0, 0);
  
  astroids.push(new Astroid(constrain(random(width) * 5, width + 100, width * 100), constrain(random(height) * 5, height + 100, height * 100), random(-0.5, 0.5), random(-1, 1), random(-0.05, 0.05), floor(random(3, 5)), random(1000)));

}

function draw() {
  background(0);
  
  for (let i = 0; i < astroids.length; i++) {
    astroids[i].update();
    astroids[i].show();
  }
  
  for (let i = 0; i < bullets.length; i++) {
    bullets[i].show();
    bullets[i].update();
  }
  
  if (frameCount % 135 == 0) {
    astroids.push(new Astroid(constrain(random(width) * 5, width + 100, width * 100), constrain(random(height) * 5, height + 100, height * 100), random(-0.5, 0.5), random(-1, 1), random(-0.05, 0.05), floor(random(3, 5)), random(1000)));
  }
  
  player.update();
  player.show();
  
  textSize(32);
  fill(0, 255, 0);
  stroke(0, 255, 0);
  let strScore = score.toString();
  text(score, width / 2 - (16 * strScore.length) / 2, 40);
  
  textSize(24);
  text(lives, 10, 32);
  
  if (lives == 0) {
    noLoop();    
    textSize(width / 10);
    fill(0, 255, 0);
    stroke(0);
    text('Game Over', width / 2 - (width / 10) * 2.5, height / 2);
  }
}


function keyPressed() {
  
  if (keyCode == 32) {
    player.bullet();
  }
}



class Player {
  
  constructor(x, y, vx, vy, a) {
    
    this.pos = createVector(x, y);
    this.vel = createVector(vx, vy);
    this.angle = a;
    this.acc = createVector(0, 0);
    this.radius = 15;
    
  }
  
  show() {
    
    push()
    
    translate(this.pos.x, this.pos.y);
    
    rotate(this.angle);
    
    stroke(0, 255, 0);
    rectMode(CORNER);
    fill(0, 75, 0);
    triangle(0 - this.radius, 0 - this.radius,0 - this.radius, 0 + this.radius, 0 + this.radius * 2, 0);
    rect(0 - (this.radius + this.radius / 2), 0 - this.radius * 0.75, this.radius / 2, this.radius * 0.5);
    rect(0 - (this.radius + this.radius / 2), 0 + this.radius * 0.25, this.radius / 2, this.radius * 0.5);
    
    pop();
  }
  
  bullet() {
    bullets.push(new Bullet(this));
  }
  
  collides(object) {
    
    if (this.pos.x < object.pos.x + object.size / 2 && this.pos.x > object.pos.x - object.size / 2 && this.pos.y < object.pos.y + object.size / 2 && this.pos.y > object.pos.y - object.size / 2) {
      return true;
    } else {
      return false;
    }
  }
  
  update() {
    
    if (this.pos.x < -this.radius * 2) {
      this.pos.x = width + this.radius;
    }
    if (this.pos.x > width + this.radius * 2) {
      this.pos.x = 0 - this.radius;
    }
    if (this.pos.y < -this.radius * 2) {
      this.pos.y = height + this.radius;
    }
    if (this.pos.y > height + this.radius * 2) {
      this.pos.y = 0 - this.radius;
    }
    
    if (keyIsDown(RIGHT_ARROW)) {
      this.angle += 0.05;
    } else if (keyIsDown(LEFT_ARROW)) {
      this.angle -= 0.05;
    }
    
    if (keyIsDown(UP_ARROW)) {
      this.acc = p5.Vector.fromAngle(this.angle);
      this.acc.setMag(thrust);
    }
    
    for (let i = 0; i < astroids.length; i++) {
      if (this.collides(astroids[i])) {
        lives -= 1;
      }
    }
      
    this.vel.add(this.acc);
    
    this.vel.mult(resistance);
    
    this.vel.limit(5);
    
    this.pos.add(this.vel);
    
    this.acc.set(0, 0);
    
  }
}



class Bullet {
  
  constructor(object) {
    this.pos = createVector(object.pos.x, object.pos.y);
    this.angle = player.angle + PI / 2;
    this.vel = p5.Vector.fromAngle(this.angle + 1.5 * PI, bulletSpeed);
  }
  
  collides(object) {
    
    if (this.pos.x < object.pos.x + object.size && this.pos.x > object.pos.x - object.size && this.pos.y < object.pos.y + object.size && this.pos.y > object.pos.y - object.size) {
      return true;
    } else {
      return false;
    }
  }
  
  update() {
    
    for (let i = 0; i < astroids.length; i++) {
      if (this.collides(astroids[i])) {
        
        let stage = astroids[i].stage;
        let astroidPosX = astroids[i].pos.x;
        let astroidPosY = astroids[i].pos.y;
        
        astroids.splice(i, 1);
        bullets.splice(bullets.indexOf(this), 1);
        
        if (stage != 2) {
          astroids.push(new Astroid(astroidPosX, astroidPosY, random(-0.5, 0.5), random(-0.5, 0.5), random(-0.03, 0.03), stage - 1, random(1000)));
          astroids.push(new Astroid(astroidPosX, astroidPosY, random(-0.5, 0.5), random(-0.5, 0.5), random(-0.03, 0.03), stage - 1, random(1000)));
        }
        
        score += 1;
      }
    }
    
    this.pos.add(this.vel);
    
    if (this.pos.x < -10 || this.pos.x > width + 10 || this.pos.y < -10 || this.pos.y > height + 10) {
      bullets.splice(bullets.indexOf(this), 1);
    }
    
  }
  
  show() {
    
    push();
    
    rectMode(CENTER);
    fill(0, 75, 0);
    stroke(0, 255, 0);
    translate(this.pos.x, this.pos.y);
    rotate(this.angle);
    rect(0, 0, 5, 20);
    
    pop();
    
  }
  
}


class Astroid {
  
  constructor(x, y, xv, yv, av, size, num) {
    
    this.pos = createVector(x, y);
    this.vel = createVector(xv, yv);
    this.aVel = av;
    this.size = size * 15;
    this.angle = 0;
    this.stage = size;
    this.num = num;
    
  }
  
  update() {
    
    if (this.pos.x < - (this.size / 2)) {
      this.pos.x = width + this.size / 2;
    }
    if (this.pos.x > width + this.size / 2) {
      this.pos.x = - (this.size / 2);
    }
    if (this.pos.y < - (this.size / 2)) {
      this.pos.y = height + this.size / 2;
    }
    if (this.pos.y > height + this.size / 2) {
      this.pos.y = - (this.size / 2);
    }
    
    this.pos.add(this.vel);
    this.angle += this.aVel;
    
  }
  
  show() {
  
    push();
    let noiseX = 0;
    let radius = this.size / 2;
    translate(this.pos.x, this.pos.y);
    noFill();
    beginShape();
    for (let i = 0; i < TWO_PI; i += PI / 100) {
    
      let x = sin(i) * radius + map(noise(noiseX, this.num), 0, 1, -5, 5);
      let y = cos(i) * radius + map(noise(noiseX, this.num), 0, 1, -5, 5);
      stroke(0, 255, 0);
      strokeWeight(2);
      vertex(x, y);
    
      noiseX = sin(i) * 5;
    
    }
    endShape(CLOSE);
    pop();
    
  }
  
}