class Movement {
  constructor(next, visited) {
    this.next = next;
    this.visited = visited;
  }
}