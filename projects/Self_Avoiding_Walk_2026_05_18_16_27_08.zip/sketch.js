let grid;

let w = 20;
let cols, rows;

let position;

function setup() {
  createCanvas(windowWidth, windowHeight);
  
  // frameRate(0.1);
    
  cols = floor(width / w);
  rows = floor(height / w);
  
  position = createVector(floor(random(cols)), floor(random(rows)));
  
  grid = create2DArray(cols, rows);
  
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      grid[i][j] = new Movement(-1, false);
    }
  }
  
  grid[position.x][position.y] = new Movement(-1, true);
  
}

function draw() {
  background(80, 80, 100);
  
  displayGrid();
  
  let availableMoves = getAvailableMoves(position);
  
  if (availableMoves.length < 1) {
    
  }
  
  let m = random(availableMoves);
  
  grid[position.x][position.y] = new Movement(m, true);
  position.add(m);
  
  displayGrid();
  
}

function getAvailableMoves(position) {
  let availableMoves = [];
  
  let left = createVector(-1, 0);
  let right = createVector(1, 0);
  let up = createVector(0, -1);
  let down = createVector(0, 1);
  
  if (isValidMove(p5.Vector.add(position, left))) {
    availableMoves.push(left);
  }
  if (isValidMove(p5.Vector.add(position, right))) {
    availableMoves.push(right);
  }
  if (isValidMove(p5.Vector.add(position, up))) {
    availableMoves.push(up);
  }
  if (isValidMove(p5.Vector.add(position, down))) {
    availableMoves.push(down);
  }
  
  return availableMoves;
}

function isValidMove(position) {
  if (position.x < 0 || position.x >= cols || position.y < 0 || position.y >= rows) {
    return false;
  }
  return !grid[position.x][position.y].visited;
}

function displayGrid() {
  for (let i = 0; i < grid.length; i++) {
    for (let j = 0; j < grid[i].length; j++) {
      
      if (grid[i][j].visited) {
        fill(255);
        noStroke();
        circle(i * w + w / 2, j * w + w / 2, w / 3);
        stroke(255);
        strokeWeight(2);
        let dir = grid[i][j].next;
        if (dir && dir != -1) {
          line(i * w + w / 2, j * w + w / 2, (i + dir.x) * w + w / 2, (j + dir.y) * w + w / 2);
        }
      }
      
    }
  }
}

function getNeighbors(i, j) {
  let neighbors = [];
  if (i - 1 >= 0) {
    neighbors.push(createVector(i-1, j)); // left
  }
  if (i + 1 < cols) {
    neighbors.push(createVector(i+1, j)); // right
  }
  if (j - 1 >= 0) {
    neighbors.push(createVector(i, j-1)); // up
  }
  if (j + 1 < rows) {
    neighbors.push(createVector(i, j+1)); // down
  }
  return neighbors;
}

function keyPressed() {
  if (keyCode == 32) {
    
    for (let i = 0; i < cols; i++) {
      for (let j = 0; j < rows; j++) {
        grid[i][j] = new Movement(-1, false);
      }
    }
    
    position = createVector(cols - 1, rows - 1);
    
    grid[position.x][position.y] = new Movement(-1, true);
  }
}