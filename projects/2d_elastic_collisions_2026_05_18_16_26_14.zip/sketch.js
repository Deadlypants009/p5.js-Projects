let particles = [];

let particleAmount = 0;

let elasticity = 0.98;

let gravity;

let mouseDown = false;
let mouseMode = "placing";

let c = 0;

let fps = 0;

function setup() {
  createCanvas(windowWidth, windowHeight);
  
  colorMode(HSB);
  
  frameRate(60);
  
  gravity = createVector(0, 0.1);
  
  for (let i = 0; i < particleAmount; i++) {
    particles.push(new Particle(random(width), random(height), c));
    c = (c + 1) % 360;
  }
  
  fill(0, 100, 100); // sets initial color so you can see text
  stroke(0, 0, 100);
}

function draw() {
  background(0);
  
  if (frameCount % 10 == 0) {
    fps = floor(frameRate());
  }
  
  text(fps, width - 20, 10);
  text(particles.length, 0, 10);
  text(mouseMode, 0, 25);
  
  if (mouseDown && mouseMode == "placing") {
    particles.push(new Particle(mouseX, mouseY, c));
    c = (c + 1) % 360;
  }
  
  if (mouseDown && mouseMode == "attracting") {
    for (let particle of particles) {
      let force = p5.Vector.sub(createVector(mouseX, mouseY), particle.position);
      force.limit(0.75);
      particle.applyForce(force);
    }
  }
  if (mouseDown && mouseMode == "pushing") {
    for (let particle of particles) {
      let force = p5.Vector.sub(createVector(mouseX, mouseY), particle.position);
      force.limit(0.5);
      force.mult(-1);
      particle.applyForce(force);
    }
  }
  
  for (let particle of particles) {
    particle.show();
  }
  
  for (let particle of particles) {
    particle.applyForce(gravity);
    particle.edges();
    particle.update();
  }  
  
  for (let i = 0; i < particles.length; i++) {
    for (let j = i + 1; j < particles.length; j++) {
      particles[i].collide(particles[j]);
    }
  }

}


function keyPressed() {
  if (keyCode == 32) {
    if (mouseMode == "placing") {
      mouseMode = "attracting";
    } else if (mouseMode == "attracting") {
      mouseMode = "pushing";
    } else if (mouseMode == "pushing") {
      mouseMode = "placing";
    }
  }
}

function mousePressed() {
  mouseDown = true;
}

function mouseReleased() {
  mouseDown = false;
}
