let gridSize;
let players = ['red', 'yellow'];
let currentPlayer = 0;

let board = [
  ['x','x','x','x','x','x','x'],
  ['x','x','x','x','x','x','x'],
  ['x','x','x','x','x','x','x'],
  ['x','x','x','x','x','x','x'],
  ['x','x','x','x','x','x','x'],
  ['x','x','x','x','x','x','x']
];

function setup() {
  gridSize = windowHeight / 7;
  createCanvas(gridSize * 7, gridSize * 7);
}

function gravity() {
  
    for (let i = 0; i < 5; i++) {
      for (let j = 0; j < 7; j++) {
        if (board[i][j] != 'x' && board[i + 1][j] == 'x' && i + 1 != 6) { 
          if (board[i][j] == 'red') {
           board[i + 1][j] = 'red'
          } else{
            board[i + 1][j] = 'yellow';
          }
          board[i][j] = 'x';
        }
      }
    }
}

function mousePressed(){
  if (board[0][mouseGridPos] == 'x'){
    if (currentPlayer == 0){
   board[0][mouseGridPos] = 'red'
   currentPlayer = (currentPlayer + 1) % 2;
  } else {
    board[0][mouseGridPos] = 'yellow'
    currentPlayer = (currentPlayer + 1) % 2;
  }
 }
}

function draw() {
  background(0, 0, 255);
  
  for (let i = 0; i < 6; i ++) {
    for (let j = 0; j < 7; j++) {
      
      //blue background thing with white circles
      fill(255);
      ellipse(gridSize * j + (gridSize * 0.5), gridSize * i + (gridSize * 1.5), gridSize, gridSize);
      rect(0, 0, width, gridSize);
      
      //draw red
      if (board[i][j] == players[0]) {
        fill(255, 0, 0);
        ellipse(gridSize * j + (gridSize * 0.5), gridSize * i + (gridSize * 1.5), gridSize, gridSize);
        
      }
      //draw yellow
      if (board[i][j] == players[1]) {
        fill(255, 255, 0);
        ellipse(gridSize * j + (gridSize * 0.5), gridSize * i + (gridSize * 1.5), gridSize, gridSize);
        
      }
      
      mouseGridPos = ceil(mouseX / gridSize -1);
      
      gravity();
    }
  }
}