let bright = 'Ñ@#W$9876543210?!abc;:+=-,._  ';

let img;

function preload() {
  
  img = loadImage('mozart.jpeg');
  
}

function setup() {
  createCanvas(400, 400);
  
  background(0);
  
  
  let w = width / img.width;
  let h = height / img.height;
  
  
  img.loadPixels();
  
  for (let y = 0; y < img.height; y++) {
    for (let x = 0; x < img.width; x++) {
      
      let i = (x + y * img.width) * 4;
      
      let r = img.pixels[i + 0];
      let g = img.pixels[i + 1];
      let b = img.pixels[i + 2];
      
      let avg = (r + g + b) / 3;
      
      let l = floor(map(avg, 0, 255, bright.length, 0));
      
      fill(avg);
      text(bright.charAt(l), x * (w + 0.5), y * (h + 0.5));
      
    }
  }
  
}