let points = [];

let numPoints = 20;

function setup() {
  createCanvas(400, 400);
    
  for (let i = 0; i < numPoints; i++) {
    points.push(createVector(random(40, width - 40), random(40, height - 40)))
  }
  
  drawFrame();
}

function drawFrame() {
  background(0);
  
  noStroke();
  fill(255);
  
  for (let p of points) {
    circle(p.x, p.y, 4);
  }
  
  let pointArr = giftWrap(points);
  
  fill(255, 0, 255, 40);
  stroke(255, 0, 255);
  
  beginShape();
  
  for (let i = 0; i < pointArr.length; i++) {
    vertex(pointArr[i].x, pointArr[i].y);
  }
  
  endShape(CLOSE);
  
  stroke(200, 0, 200);
  fill(255, 200, 255);
  
  for (let p of pointArr) {
    circle(p.x, p.y, 8);
  }
  
  stroke(100, 0, 100);
  fill(255, 0, 200);
  circle(pointArr[0].x, pointArr[0].y, 8);
  
}


function giftWrap(pointArr) {
  
  let outsidePoints = [];
  
  let leftMostPoint = createVector(Infinity, 0);
  
  for (let i = 0; i < pointArr.length; i++ ) {
    if (pointArr[i].x < leftMostPoint.x) {
      leftMostPoint = pointArr[i];
    }
  }
  
  outsidePoints.push(leftMostPoint);
  
  let currentPoint = leftMostPoint;
  let currentAngle = createVector(0, 1);
  
  while (true) {
    
    let smallestAngle = Infinity;
    let nextPoint = null;
    
    for (let i = 0; i < pointArr.length; i++) {
      
      if (currentPoint != pointArr[i]) {
        if (currentAngle.angleBetween(p5.Vector.sub(currentPoint, pointArr[i])) < smallestAngle) {
          smallestAngle = currentAngle.angleBetween(p5.Vector.sub(currentPoint, pointArr[i]));
          nextPoint = pointArr[i];
        }
      }
    
    }
    
    currentAngle = p5.Vector.sub(nextPoint, currentPoint);
    
    outsidePoints.push(nextPoint);
    currentPoint = nextPoint;
    
    if (currentPoint == leftMostPoint) {
      break;
    }
    
  }
  
  return outsidePoints;
  
}