let itterations = 10000000000;
let j = 0;
let pie = 0;

function calculate() {
  for (let i = 1; i < itterations; i = i + 2) {
    if (j % 2 == 0) {
      pie += 4 / i; 
    } else {
      pie -= 4 / i;
    }
    j++;
  }
  console.log(pie);
}

calculate();