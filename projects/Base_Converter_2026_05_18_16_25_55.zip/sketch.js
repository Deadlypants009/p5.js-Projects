let inputBase;
let outputBase;
let number;
let output;

let div;

function setup() {
  createCanvas(200, 200);
  div = createDiv();
  inputBase = createInput();
  outputBase = createInput();
  number = createInput();
}

function draw() {
  background(255);
  if (inputBase.value() > 1 && outputBase.value() > 1) {
    output = baseToBase(inputBase.value(), outputBase.value(), number.value());
  } else {
    output = baseToBase(0, 0, 0);
  }
  textAlign(CENTER);
  textSize(32);
  text(output, width / 2, height / 2);
}

function baseToBase(inputBase, outputBase, number) {
  let decimal = baseToDecimal(number, inputBase);
  let output = decimalToBase(decimal, outputBase);
  output = parseInt(output);
  return output;
}


function baseToDecimal(number, inputBase) {
  let stringNumber = number.toString();
  let length = 0;
  let running = true;
  while (running) {
    if (stringNumber.charAt(length) == '') {
      running = false;
    } else {
      length++;
    }
  }
  let output = 0;
  for (let i = 0; i < length; i++) {
    let num = parseInt(stringNumber.charAt(i));
    output += num * pow(inputBase, length - i - 1);
  }
  output = parseInt(output);
  return output;
}


function decimalToBase(number, outputBase) { 
  let output = ''; 
  while (number > 0) { 
    output = (number % outputBase) + output; 
    number = floor(number / outputBase); 
  }
  output = parseInt(output);
  return output; 
} 