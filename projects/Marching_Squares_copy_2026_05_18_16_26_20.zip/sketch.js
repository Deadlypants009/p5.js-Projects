let grid;

let resolution = 5; // must be a factor of width and height

let w, h;

let gridShowing = false;

let dNoise = 0.1; // zoom

let noiseX = 0;

let time = 0;

function keyPressed() {
  if (keyCode == 32) {
    gridShowing = !gridShowing;
  }
}

function setup() {
  createCanvas(400, 400);
  
  noiseSeed();
  
  w = width / resolution + 1;
  h = height / resolution + 1;
  
  grid = create2DArray(w, h);
  fill2DArray(grid, 0);
}

function draw() {
  background(0);
  
  generateNoise(grid);
  
  if (gridShowing) {
    showGrid();
  }
  
  time += deltaTime * 0.0005;
  
  for (let i = 0; i < w - 1; i++) {
    for (let j = 0; j < h - 1; j++) {
      // corner values
      let a = round(grid[i][j]);
      let b = round(grid[i + 1][j]);
      let c = round(grid[i + 1][j + 1]);
      let d = round(grid[i][j + 1]);
      
      // positions of the midpoints
      let ab = createVector((i + 0.5) * resolution, j * resolution);
      let bc = createVector((i + 1) * resolution, (j + 0.5) * resolution);
      let cd = createVector((i + 0.5) * resolution, (j + 1) * resolution);
      let da = createVector(i * resolution, (j + 0.5) * resolution);
      
      let state = getState(a, b, c, d);
      
      switch (state) {
        case 1:
          drawLine(ab, da);
          break;
        case 2:
          drawLine(ab, bc);
          break;
        case 3:
          drawLine(bc, da);
          break;
        case 4:
          drawLine(bc, cd);
          break;
        case 5:
          drawLine(ab, bc);
          drawLine(da, cd);
          break;
        case 6:
          drawLine(ab, cd);
          break;
        case 7:
          drawLine(cd, da);
          break;
        case 8:
          drawLine(cd, da);
          break;
        case 9:
          drawLine(ab, cd);
          break;
        case 10:
          drawLine(ab, da);
          drawLine(bc, cd);
          break;
        case 11:
          drawLine(cd, bc);
          break;
        case 12:
          drawLine(da, bc);
          break;
        case 13:
          drawLine(ab, bc);
          break;
        case 14:
          drawLine(ab, da);
          break;
      }
    }
  }
}


function drawLine(p1, p2) {
  stroke(255);
  strokeWeight(1);
  line(p1.x, p1.y, p2.x, p2.y);
}




function getState(a, b, c, d) {
  return (d * 8 + c * 4 + b * 2 + a * 1);
}


function showGrid() {
  for (let i = 0; i < w; i++) {
    for (let j = 0; j < h; j++) {
      noStroke();
      // if (grid[i][j] > 0) {
      //   fill(255);
      // } else {
      //   fill(0);
      // }
      let c = map(grid[i][j], 0, 1, 0, 255);
      fill(c);
      circle(i * resolution, j * resolution, resolution / 3);
    }
  }
}





function generateNoise(arr) {
  for (let i = 0; i < arr.length; i++) {
    for (let j = 0; j < arr[i].length; j++) {
      let n = noise(i * dNoise + noiseX, j * dNoise, time);
      // if (n > 0.5) {
      //   n = 1;
      // } else {
      //   n = 0;
      // }
      arr[i][j] = pow(n + 0.4, 4);
    }
  }
}

function fill2DArray(arr, value) {
  for (let i = 0; i < arr.length; i++) {
    for (let j = 0; j < arr[i].length; j++) {
      arr[i][j] = value;
    }
  }
}
  
function create2DArray(cols, rows) {
  let arr = new Array(cols);
  for (let i = 0; i < arr.length; i++) {
    arr[i] = new Array(rows);
  }
  return arr;
}