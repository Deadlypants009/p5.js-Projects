let perceptron;

let points = [];

let learningRate = 0.0001;

let training = false;


let coeffecient = 1;
let intercept = 50;

function setup() {
  createCanvas(400, 400);
  
  perceptron = new Perceptron(2);
  
  newPoints();
  
}

function draw() {
  background(255);
  
  stroke(0);
  strokeWeight(2);
  // line(0, 0, width, height);
  
  for (let x = 0; x < width; x++) {
    fill(0);
    circle(x, x*coeffecient + intercept, 5);
  }
  
  if (training) {
    for (let i = 0; i < points.length; i++) {
      points[i].show();
    }
    for (let i = 0; i < points.length; i++) {
      let inputs = [map(points[i].x, 0, width, -1, 1), map(points[i].y, 0, height, -1, 1)];
      perceptron.train(inputs, points[i].label);
    }
  
    newPoints();
  }
  
  strokeWeight(map(abs(perceptron.weights[1]), 0, 1, 0.1, 6));
  line(30, 60, 60, 45);
  strokeWeight(map(abs(perceptron.weights[0]), 0, 1, 0.1, 6));
  line(30, 30, 60, 45);
  
  strokeWeight(2);
  fill(map(points[0].x, 0, width, 0, 255));
  circle(30, 30, 16);
  fill(map(points[0].y, 0, height, 0, 255));
  circle(30, 60, 16);
  fill((perceptron.guess([points[0].x, points[0].y]) + 1) * 255);
  circle(60, 45, 16);
}

function newPoints() {
  
  points = [];
  for (let i = 0; i < 100; i++) {
    points.push(new Point());
  }
  
}

function mousePressed() {
  
  let inputs = [map(mouseX, 0, width, -1, 1), map(mouseY, 0, height, -1, 1)];
  let guess = perceptron.guess(inputs);
  if (guess >= 0) {
    console.log('below');
  } else {
    console.log('above');
  }
}

function keyPressed() {
  if (keyCode == 32) {
    training = !training;
  }
}


class Perceptron{
  
  constructor(numInputs) {
    this.weights = [];
    for (let i = 0; i < numInputs; i++) {
      this.weights.push(random(-1, 1));
    }
  }
  
  guess(inputs) {
    let sum = 0;
    for (let i = 0; i < this.weights.length; i++) {
      sum += inputs[i] * this.weights[i];
    }
    return sum;
  }
  
  train(inputs, target) {
    let guess = perceptron.guess(inputs);
    let error = target - guess;
    
    for (let i = 0; i < this.weights.length; i++) {
      this.weights[i] += error * inputs[i] * learningRate;
    }
    
  }
  
}


class Point{
  constructor() {
    
    this.x = random(width);
    this.y = random(height);
    
    this.label = 0;
    
    //change line
    if (this.y > this.x*coeffecient + intercept) {
      this.label = 1;
    } else {
      this.label = -1;
    }
    
  }
  
  show() {
    
    if (this.label == 1) {
      fill(255, 0, 0);
    } else {
      fill(0, 0, 255);
    }
    
    circle(this.x, this.y, 16);
    
  }
}